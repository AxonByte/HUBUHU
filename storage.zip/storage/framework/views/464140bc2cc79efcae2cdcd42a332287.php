<?php $__env->startSection('content'); ?>
	<h5 class="mb-4 fw-light">
    <a class="text-reset" href="<?php echo e(url('panel/admin'), false); ?>"><?php echo e(__('admin.dashboard'), false); ?></a>
      <i class="bi-chevron-right me-1 fs-6"></i>
      <span class="text-muted"><?php echo e(__('general.gifts'), false); ?></span>

			<a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#addGiftModal" class="btn btn-sm btn-dark float-lg-end mt-1 mt-lg-0">
				<i class="bi-plus-lg me-1"></i> <?php echo e(__('general.add_new'), false); ?>

			</a>
  </h5>

<div class="content">
	<div class="row">

		<div class="col-lg-12">

			<?php if(session('success')): ?>
      <div class="alert alert-success alert-dismissible fade show" role="alert">
              <i class="bi bi-check2 me-1"></i>	<?php echo e(session('success'), false); ?>


                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                  <i class="bi bi-x-lg"></i>
                </button>
                </div>
              <?php endif; ?>

              <?php echo $__env->make('errors.errors-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="card shadow-custom border-0">

				<div class="card-body p-lg-4">

					<div class="table-responsive p-0">
						<table class="table table-hover">
						 <tbody>

               <?php if($data->count() !=  0): ?>
                  <tr>
                    <th class="active"><?php echo e(__('general.image'), false); ?></th>
                     <th class="active"><?php echo e(__('general.price'), false); ?></th>
                     <th class="active"><?php echo e(__('admin.status'), false); ?></th>
                     <th class="active"><?php echo e(__('admin.actions'), false); ?></th>
                   </tr>

                 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                    <td><img src="<?php echo e(url('public/img/gifts', $gift->image), false); ?>" width="50"></td>
                     <td><?php echo e($gift->price, false); ?></td>
                     <td>
                        <span class="badge bg-<?php echo e($gift->status ? 'success' : 'secondary', false); ?>">
                            <?php echo e($gift->status ? __('general.enabled') : __('general.disabled'), false); ?>

                        </span>
                    </td>
                     
                     <td>
                        <div class="d-flex">
                            <a href="<?php echo e(route('gifts.edit', ['gift' => $gift->id]), false); ?>" class="btn btn-success rounded-pill btn-sm me-2">
                                <i class="bi-pencil"></i>
                            </a>

                            <form method="POST" action="<?php echo e(route('gifts.destroy', ['gift' => $gift->id]), false); ?>" accept-charset="UTF-8" class="d-inline-block align-top">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger rounded-pill btn-sm actionDelete" type="button">
                                  <i class="bi-trash-fill"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                   </tr><!-- /.TR -->
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php else: ?>
                        <h5 class="text-center p-5 text-muted fw-light m-0"><?php echo e(__('general.no_results_found'), false); ?></h5>
                    <?php endif; ?>

                        </tbody>
                        </table>
                    </div><!-- /.box-body -->
            </div><!-- card-body -->
        </div><!-- card  -->

        <?php if($data->lastPage() > 1): ?>
        <?php echo e($data->onEachSide(0)->links(), false); ?>

        <?php endif; ?>
    </div><!-- col-lg-12 -->
	</div><!-- end row -->
</div><!-- end content -->

 <?php echo $__env->make('admin.add-gift', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/admin/gifts.blade.php ENDPATH**/ ?>