  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <li class="chatlist mb-1" data="<?php echo e($comment->id, false); ?>" data-msg="<?php echo e($live->user_id != $comment->user()->id || auth()->id() != $comment->user()->id ? '/' . $comment->user()->id . '/' . $comment->user()->username : '', false); ?>">
    <img src="<?php echo e(Helper::getFile(config('path.avatar').$comment->user()->avatar), false); ?>" alt="User" class="rounded-circle mr-1" width="20" height="20">
    <strong><?php echo e($comment->user()->username, false); ?></strong>

    <?php if($comment->user()->verified_id == 'yes'): ?>
      <small class="verified">
           <i class="bi-patch-check-fill"></i>
         </small>
    <?php endif; ?>

    <p class="d-inline">
      <?php echo e($comment->comment, false); ?>


      <?php if($comment->joined): ?>

        <?php if($comment->user_id == auth()->id()): ?>
          <?php echo e(__('general.you_have_joined'), false); ?>

        <?php else: ?>
          <?php echo e(__('general.has_joined'), false); ?>

        <?php endif; ?>

      <?php endif; ?>

      <?php if($comment->tip): ?>
        <?php echo e(__('general.tipped'), false); ?> <span class="badge badge-pill badge-success tipped-live px-3"><i class="bi-coin mr-1"></i> <?php echo e(Helper::priceWithoutFormat($comment->earnings), false); ?></span>
      <?php endif; ?>

      <?php if($comment->gift_id): ?>
        
        
        <?php if(isset($comment->gift->id)): ?>
          <span class="d-block w-100">
            <img src="<?php echo e(url('public/img/gifts', $comment->gift->image), false); ?>" width="100">
          </span>
        <?php endif; ?>

        <small class="d-block w-100">
          <i class="bi-gift mr-1"></i> <strong><?php echo e(__('general.sent_a_gift_for'), false); ?> <?php echo e(Helper::priceWithoutFormat($comment->earnings), false); ?></strong>
        </small>

      <?php endif; ?>
    </p>
  </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\app\resources\views/includes/comments-live.blade.php ENDPATH**/ ?>