<link href="<?php echo e(asset('public/css/core.min.css'), false); ?>?v=<?php echo e($settings->version, false); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/admin/bootstrap.min.css'), false); ?>?v=<?php echo e($settings->version, false); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/css/bootstrap-icons.css'), false); ?>?v=<?php echo e($settings->version, false); ?>" rel="stylesheet">
<link href="<?php echo e(asset('public/admin/admin-styles.css'), false); ?>?v=<?php echo e($settings->version, false); ?>" rel="stylesheet">
<?php /**PATH C:\xampp\htdocs\app\resources\views/includes/css_admin.blade.php ENDPATH**/ ?>