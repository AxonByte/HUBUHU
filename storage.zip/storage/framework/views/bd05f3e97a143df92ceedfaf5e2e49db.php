<?php $__env->startSection('title'); ?><?php echo e(__('general.live_streaming'), false); ?> <?php echo e(__('general.by'), false); ?> <?php echo e('@'.$creator->username, false); ?> -<?php $__env->stopSection(); ?>

  <?php $__env->startSection('css'); ?>
    <script type="text/javascript">
        var liveOnline = <?php echo e($live ? 'true' : 'false', false); ?>;
        <?php if($live): ?>
          var appIdAgora = '<?php echo e($settings->agora_app_id, false); ?>'; // set app id
          var agorachannelName = '<?php echo e($live->channel, false); ?>'; // set channel name
          var liveMode = true;
          var liveType = '<?php echo e($live->type, false); ?>';
          var liveCreator = <?php echo e($creator->id == auth()->id() ? 'true' : 'false', false); ?>;
          var role = "<?php echo e($creator->id == auth()->id() ? 'host' : 'audience', false); ?>";
          var availability = '<?php echo e($live->availability, false); ?>';
          var textMuteAudio = "<?php echo e(__('general.mute_audio'), false); ?>";
          var textUnmuteAudio = "<?php echo e(__('general.unmute_audio'), false); ?>";
          var textMuteVideo = "<?php echo e(__('general.mute_video'), false); ?>";
          var textUnmuteVideo = "<?php echo e(__('general.unmute_video'), false); ?>";
          
        <?php endif; ?>
    </script>

    <?php if($live): ?>
      <script src="<?php echo e(asset('public/js/agora/AgoraRTCSDK-v4.js'), false); ?>"></script>
    <?php endif; ?>
  <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="section section-sm pt-0 pb-0 h-100 section-msg position-fixed live-data" <?php if($live): ?> data="<?php echo e($live->id, false); ?>" data-creator="<?php echo e($creator->id, false); ?>" <?php endif; ?>>
      <div class="container mw-100 h-100">
        <div class="row justify-content-center h-100 position-relative">

          <div class="col-md-9 h-100 p-0 liveContainerFullScreen" <?php if($live): ?> data-id="<?php echo e($live->id, false); ?>" <?php endif; ?>>
            <div class="card w-100 rounded-0 h-100 border-0 liveContainer <?php if(! $live): ?> live_offline <?php endif; ?>" <?php if(! $live): ?> style="background:url('<?php echo e(Helper::getFile(config('path.avatar').$creator->avatar), false); ?>') no-repeat center center; background-size: cover; background-color: #000;" <?php endif; ?>>

              <div class="content <?php if(! $live): ?> px-4 py-3 <?php endif; ?> d-scrollbars container-msg">
                <?php if(! $live): ?>
                  <div class="flex-column d-flex justify-content-center text-center h-100 text-content-live">
                    <div class="w-100">

                      <?php if(! $live && $creator->id == auth()->id()): ?>
                        <h2 class="mb-0 font-montserrat"><i class="bi bi-broadcast mr-2"></i> <?php echo e(__('general.stream_live'), false); ?></h2>
                        <p class="lead mt-0"><?php echo e(__('general.create_live_stream_subtitle'), false); ?></p>
                        <button class="btn btn-primary btn-sm w-small-100 btnCreateLive">
                          <i class="bi bi-plus-lg mr-1"></i> <?php echo e(__('general.create_live_stream'), false); ?>

                        </button>

                        <div class="mt-3 d-block ">
                          <a href="<?php echo e(url('/'), false); ?>" class="text-white"><i class="bi bi-arrow-left"></i> <?php echo e(__('error.go_home'), false); ?></a>
                        </div>

                      <?php elseif(! $live && $creator->id != auth()->id()): ?>

                        <h2 class="mb-0 font-montserrat"><i class="bi bi-broadcast mr-2"></i> <?php echo e(__('general.welcome_live_room'), false); ?></h2>
                        <?php if($checkSubscription): ?>
                          <p class="lead mt-0"><?php echo e(__('general.info_offline_live'), false); ?></p>

                          <div class="mt-3 d-block ">
                            <a href="<?php echo e(url('/'), false); ?>" class="text-white"><i class="bi bi-arrow-left"></i> <?php echo e(__('error.go_home'), false); ?></a>
                          </div>

                        <?php else: ?>
                          <p class="lead mt-0"><?php echo e(__('general.info_offline_live_non_subscribe'), false); ?></p>
                          <a href="#" class="btn btn-primary btn-sm w-small-100">
                            <i class="feather icon-unlock mr-1"></i> <?php echo e(__('general.offline_now'), false); ?>

                          </a>

                          <div class="mt-3 d-block ">
                            <a href="<?php echo e(url('/'), false); ?>" class="text-white"><i class="bi bi-arrow-left"></i> <?php echo e(__('error.go_home'), false); ?></a>
                          </div>

                        <?php endif; ?>

                      <?php endif; ?>
                    </div>
                  </div><!-- flex-column -->
                <?php else: ?>

                  <div class="live-top-menu">
                  	<div class="w-100">
                      <img src="<?php echo e(Helper::getFile(config('path.avatar').$creator->avatar), false); ?>" class="rounded-circle avatar-live mr-2" width="40" height="40">
                  		<span class="font-weight-bold text-white text-shadow-sm d-lg-inline-block d-none"><?php echo e($creator->username, false); ?></span>
                      <span class="font-weight-bold text-white text-shadow-sm d-lg-none d-inline-block"><?php echo e(str_limit($creator->username, 7, '...'), false); ?></span>
                  		<small class="font-weight-bold text-white text-shadow-sm" style="position: absolute; top: <?php echo e($limitLiveStreaming ? '65px;' : '50px;', false); ?> left: 67px;">
                        
                        <?php if(!$limitLiveStreaming): ?>
                        <?php echo e(__('general.started'), false); ?> <span class="timeAgo" data="<?php echo e(date('c', strtotime($live->created_at)), false); ?>"></span>
                        <?php endif; ?>
                        
                        <?php if($creator->id == auth()->id()): ?>
                        <span class="w-100 <?php if($amountTips === 0): ?> display-none <?php else: ?> d-block <?php endif; ?>" id="earned">
                          <i class="bi-coin mr-1"></i> <span id="amountTip"><?php echo e(Helper::formatPrice($amountTips), false); ?></span>
                        </span>
                        <?php endif; ?>
                      </small>


                      <?php if($live && ! $paymentRequiredToAccess && $limitLiveStreaming): ?>
                        <small class="text-white text-shadow-sm limitLiveStreaming">
                          <i class="bi bi-clock mr-1"></i> <span><?php echo e($limitLiveStreaming, false); ?></span> <?php echo e(__('general.minutes'), false); ?>

                        </small>
                      <?php endif; ?>


                      <div class="float-right">
                        <span class="live text-uppercase mr-2"><?php echo e(__('general.live'), false); ?></span>
                        <?php if($creator->id == auth()->id()): ?>
                        <span class="live-views text-uppercase mr-2">
                          <i class="bi bi-eye mr-2"></i> <span id="liveViews"><?php echo e($live->onlineUsers->count(), false); ?></span>
                        </span>
                        <?php endif; ?>

                        <?php if($creator->id != auth()->id()): ?>
                          <button class="live-views text-uppercase mr-2" id="liveAudio">
                            <i class="fas fa-volume-up"></i>
                          </button>
                        <?php endif; ?>

                        <?php if($creator->id == auth()->id()): ?>
                          <span class="live-options text-shadow-sm mr-2" id="optionsLive" role="button" data-toggle="dropdown">
                            <i class="bi bi-gear"></i>
                          </span>

                          <div class="dropdown-menu dropdown-menu-right menu-options-live mb-1" aria-labelledby="optionsLive">
                            <div id="mute-audio">
                              <a class="dropdown-item"><i class="bi-mic-mute mr-1"></i> <?php echo e(__('general.mute_audio'), false); ?></a>
                            </div>
                            <div id="mute-video">
                              <a class="dropdown-item"><i class="bi-camera-video-off mr-1"></i> <?php echo e(__('general.mute_video'), false); ?></a>
                            </div>
                            <div class="dropdown-divider"></div>
                            <div id="camera-list"></div>
                            <div id="mic-list"></div>
                          </div>

                          <form method="POST" action="<?php echo e(url('end/live/stream', $live->id), false); ?>" accept-charset="UTF-8" class="d-none" id="formEndLive">
                            <?php echo csrf_field(); ?>
                            </form>
                        <span class="close-live text-shadow-sm" id="endLive" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('general.end_live'), false); ?>">
                          <i class="bi bi-x-lg"></i>
                        </span>

                      <?php else: ?>
                      <span class="exit-live text-shadow-sm" id="menuToggle" role="button" data-toggle="dropdown">
                        <i class="bi-three-dots"></i>
                      </span>

                      <div class="dropdown-menu dropdown-menu-right menu-options-live mb-1" aria-labelledby="menuToggle">
                        <?php if($live->type == 'normal'): ?>
                        <a href="javascript:void(0);" class="dropdown-item" data-toggle="modal" data-target="#reportLiveStream">
                          <i class="bi-flag mr-2"></i> <?php echo e(__('general.report_live_stream'), false); ?>

                        </a>
                        <?php endif; ?>

                        <a href="javascript:void(0);" class="dropdown-item" id="exitLive">
                          <i class="feather icon-log-out mr-2"></i> <?php echo e(__('general.exit_live_stream'), false); ?>

                        </a>
                      </div>

                        
                      <?php endif; ?>

                      </div>
                    </div>
                  </div>

                  <div id="full-screen-video"></div>

                <?php endif; ?>

              </div><!-- container-msg -->

              </div><!-- card -->
            </div><!-- end col-md-8 -->

          <!-- Chat Box -->
          <div class="col-md-3 h-100 p-0 border-right wrapper-msg-inbox wrapper-live-chat">

          <div class="card w-100 rounded-0 h-100 border-0">

            <div class="w-100 p-3 border-bottom titleChat">
            	<div class="w-100">
            		<span class="h5 align-top font-weight-bold"><?php echo e(__('general.chat'), false); ?></span>
              </div>
            </div>

            <div class="content px-4 py-3 d-scrollbars container-msg chat-msg" id="contentDIV">

              <div class="div-flex"></div>

              <?php if($live && ! $paymentRequiredToAccess): ?>
              <ul class="list-unstyled mb-0" id="allComments">
                <?php echo $__env->make('includes.comments-live', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </ul>
              <?php endif; ?>


            </div>

        <div class="card-footer bg-transparent position-relative <?php if(! $live): ?> offline-live <?php endif; ?>">
            <!-- Alert -->
            <div class="alert alert-danger my-3 display-none" id="errorMsg">
             <ul class="list-unstyled m-0" id="showErrorMsg"></ul>
           </div><!-- Alert -->

            <form action="<?php echo e(url('comment/live'), false); ?>" method="post" accept-charset="UTF-8" id="formSendCommentLive" enctype="multipart/form-data">

              <?php if($live): ?>
                <input type="hidden" name="live_id" value="<?php echo e($live->id, false); ?>">
              <?php endif; ?>

              <?php echo csrf_field(); ?>
              

                  <div class="d-flex" style="align-items: center;">

                    <div class="w-100 h-100 position-relative">
                      <div class="live-blocked rounded-pill blocked <?php if($live && ! $paymentRequiredToAccess): ?> display-none <?php endif; ?>"></div>
                      <input type="text" class="form-control border-0 emojiArea" id="commentLive" placeholder="<?php echo e(__('general.write_something'), false); ?>" name="comment" autocomplete="off" />
                    </div>

                    <?php if($live && ! $paymentRequiredToAccess): ?>
                      <button style="display:none;" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn icons-live e-none align-bottom buttons-live <?php if(auth()->user()->dark_mode == 'off'): ?> text-primary <?php else: ?> text-white <?php endif; ?> rounded-pill">
                          <i class="bi-emoji-smile f-size-25"></i>
                      </button>

                      <div class="dropdown-menu dropdown-menu-right dropdown-emoji custom-scrollbar" aria-labelledby="dropdownEmoji">
                        <?php echo $__env->make('includes.emojis', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                      </div>
                    <?php endif; ?>

                    <?php if($creator->id != auth()->id()): ?>
                      <?php if($live && ! $paymentRequiredToAccess): ?>

                      <?php if($settings->gifts): ?>
                      <button type="button" data-toggle="modal" title="<?php echo e(__('general.gifts'), false); ?>" data-target="#giftsForm" class="btn icons-live f-size-25 btn-tooltip e-none align-bottom buttons-live <?php if(auth()->user()->dark_mode == 'off'): ?> text-primary <?php else: ?> text-white <?php endif; ?> rounded-pill">
                        <i class="bi-gift"></i>
                      </button>

                      <?php else: ?>
                      
                      <?php endif; ?>

                      <?php endif; ?>
                    <?php endif; ?>
                    <span class="btn-primary btn icons-live e-none align-bottom buttons-live" id="openMessage">
                      <i class="bi bi-chat-dots-fill"></i>
                    </span>
                      
                    <span class="btn-primary btn icons-live e-none align-bottom buttons-live" id="sendLiveChat">
                      <i class="bi bi-chevron-right"></i>
                    </span>
                    <?php if($live && ! $paymentRequiredToAccess): ?>
                    <span style="display:none;" class="btn icons-live e-none align-bottom buttons-live <?php echo e($likeActive ? 'active' : null, false); ?> button-like-live <?php if(auth()->user()->dark_mode == 'off'): ?> text-primary <?php else: ?> text-white <?php endif; ?> rounded-pill">
                      <i class="bi bi-heart<?php echo e($likeActive ? '-fill' : null, false); ?>"></i>
                    </span>

                    <div class="py-3" style="display:none;">
                      <small id="counterLiveLikes">
                        <?php if($live && $likes != 0): ?>
                          <?php echo e($likes, false); ?>

                        <?php endif; ?>
                      </small>
                    </div>
                    <?php endif; ?>

                  </div><!-- justify-content-between -->
                </form>
              </div>

            </div><!-- end card -->

          </div><!-- end col-md-3 -->

          </div><!-- end row -->
        </div><!-- end container -->
</section>

<?php if($live && $paymentRequiredToAccess): ?>
<?php echo $__env->make('includes.modal-pay-live', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if($creator->id != auth()->id() && $live && ! $paymentRequiredToAccess): ?>
<div class="modal fade modalReport" id="reportLiveStream" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-danger modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <h6 class="modal-title font-weight-light" id="modal-title-default"><i class="fas fa-flag mr-1"></i> <?php echo e(__('general.report_live_stream'), false); ?></h6>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="fa fa-times"></i>
        </button>
      </div>
 <!-- form start -->
 <form method="POST" action="<?php echo e(url('report/live', $creator->id), false); ?>" enctype="multipart/form-data">
    <div class="modal-body">
      <?php echo csrf_field(); ?>
      <!-- Start Form Group -->
      <div class="form-group">
        <label><?php echo e(__('admin.please_reason'), false); ?></label>
          <select name="reason" class="form-control custom-select">
           <option value="spoofing"><?php echo e(__('admin.spoofing'), false); ?></option>
              <option value="copyright"><?php echo e(__('admin.copyright'), false); ?></option>
              <option value="privacy_issue"><?php echo e(__('admin.privacy_issue'), false); ?></option>
              <option value="violent_sexual"><?php echo e(__('admin.violent_sexual_content'), false); ?></option>
              <option value="spam"><?php echo e(__('general.spam'), false); ?></option>
              <option value="fraud"><?php echo e(__('general.fraud'), false); ?></option>
            </select>

            <textarea name="message" rows="" cols="40" maxlength="200" placeholder="<?php echo e(__('general.message'), false); ?>*" class="form-control mt-2 textareaAutoSize"></textarea>
            
            </div><!-- /.form-group-->
        </div><!-- Modal body -->

       <div class="text-center pb-4">         
         <button type="submit" class="btn btn-xs btn-white sendReport ml-auto"><i></i> <?php echo e(__('general.report_live_stream'), false); ?></button>
         <div class="w-100 mt-2">
          <button type="button" class="btn border text-white" data-dismiss="modal"><?php echo e(__('admin.cancel'), false); ?></button>
        </div>
       </div>

       </form>
      </div><!-- Modal content -->
    </div><!-- Modal dialog -->
  </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

  <?php if($live && $paymentRequiredToAccess): ?>
    <script>
    // Payment Required
  		$('#payLiveForm').modal({
  				 backdrop: 'static',
  				 keyboard: false,
  				 show: false
  		 });
       $(document).ready(function() {
          // Check if the element exists
          const interval = setInterval(() => {
          if ($('#payLiveBtn').length) {
              $('#payLiveBtn').trigger('click'); // Trigger the click event
              clearInterval(interval); // Stop checking once the element is found
            }
          }, 100);
        });

       //<---------------- Pay Live ----------->>>>
 			 $(document).on('click','#payLiveBtn',function(s) {
 				 s.preventDefault();
 				 var element = $(this);
 				 element.attr({'disabled' : 'true'});
 				 element.find('i').addClass('spinner-border spinner-border-sm align-middle mr-1');

 				 (function(){
 						$('#formPayLive').ajaxForm({
 						dataType : 'json',
 						success:  function(result) {

 							if (result.success) {
 								window.location.reload();
 							} else {
 								if (result.errors) {

 									var error = '';
 									var $key = '';

 									for ($key in result.errors) {
 										error += '<li><i class="far fa-times-circle"></i> ' + result.errors[$key] + '</li>';
 									}

 									$('#showErrorsPayLive').html(error);
 									$('#errorPayLive').show();
 									element.removeAttr('disabled');
 									element.find('i').removeClass('spinner-border spinner-border-sm align-middle mr-1');
 								}
 							}

 						 },
 						 error: function(responseText, statusText, xhr, $form) {
 								 // error
 								 element.removeAttr('disabled');
 								 element.find('i').removeClass('spinner-border spinner-border-sm align-middle mr-1');
 								 swal({
 										 type: 'error',
 										 title: error_oops,
 										 text: error_occurred+' ('+xhr+')',
 									 });
 						 }
 					 }).submit();
 				 })(); //<--- FUNCTION %
 			 });//<<<-------- * END FUNCTION CLICK * ---->>>>


      let wakeLock = null;

      async function requestWakeLock() {
          try {
              if ('wakeLock' in navigator) {
                  wakeLock = await navigator.wakeLock.request('screen');
                  wakeLock.addEventListener('release', () => {
                      console.log('Screen Wake Lock released');
                  });
                  console.log('Screen Wake Lock is active');
              }
          } catch (err) {
              console.error(`${err.name}, ${err.message}`);
          }
      }

      // Re-acquire the wake lock on visibility change (e.g., when user switches tabs)
      document.addEventListener('visibilitychange', () => {
          if (wakeLock !== null && document.visibilityState === 'visible') {
              requestWakeLock();
          }
      });

      // Request wake lock when the page is loaded and live is active
      <?php if($live): ?>
          document.addEventListener('DOMContentLoaded', requestWakeLock);
      <?php endif; ?>

      document.addEventListener('DOMContentLoaded', function() {
          var commentInput = document.getElementById('commentLive');
          if (commentInput) {
              commentInput.addEventListener('focus', function() {
                  setTimeout(function() {
                      commentInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
                  }, 300); // Delay helps after keyboard opens
              });
          }
      });
    </script>
  <?php endif; ?>
  <script>
  document.addEventListener('DOMContentLoaded', function() {
      const openMessageBtn = document.getElementById('openMessage');
      if (openMessageBtn) {
          openMessageBtn.addEventListener('click', function() {
              // Replace with your actual message route if different
              const url = "<?php echo e(url('messages'), false); ?>";
              const width = 600;
              const height = 800;
              const left = (screen.width - width) / 2;
              const top = (screen.height - height);
              window.open(
                  url,
                  'MessagePopup',
                  `width=${width},height=${height},left=${left},top=${top},resizable=yes,scrollbars=yes`
              );
          });
      }
  });
  </script>

  <?php if($live && !$paymentRequiredToAccess): ?>
    <script src="<?php echo e(asset('public/js/live.js'), false); ?>?v=<?php echo e($settings->version, false); ?>"></script>
    <script src="<?php echo e(asset('public/js/agora/agora-broadcast-client-v4.js'), false); ?>?v=<?php echo e($settings->version, false); ?>"></script>

    <?php if($creator->id == auth()->id() || !$paymentRequiredToAccess): ?>
      <script>
      // Start Live
      $(document).ready(async function() {
        await joinChannel();
      });
    	</script>
      <?php endif; ?>

  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/users/live.blade.php ENDPATH**/ ?>