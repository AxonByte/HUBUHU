

<?php $__env->startSection('content'); ?>
	<h5 class="mb-4 fw-light">
    <a class="text-reset" href="<?php echo e(url('panel/admin'), false); ?>"><?php echo e(__('admin.dashboard'), false); ?></a>
      <i class="bi-chevron-right me-1 fs-6"></i>
      <span class="text-muted"><?php echo e(__('general.announcements'), false); ?></span>

  </h5>

<div class="content">
	<div class="row">

		<div class="col-lg-12">

    <?php if(session('success_message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check2 me-1"></i>	<?php echo e(session('success_message'), false); ?>


              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                <i class="bi bi-x-lg"></i>
              </button>
              </div>
            <?php endif; ?>

		<?php echo $__env->make('errors.errors-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="card shadow-custom border-0">
				<div class="card-body p-lg-5">

					 <form method="POST" action="<?php echo e(url('panel/admin/announcements'), false); ?>" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>

            <div class="row mb-3">
		          <label class="col-sm-2 col-form-labe text-lg-end"><?php echo e(__('general.announcement_content'), false); ?></label>
		          <div class="col-sm-10">
                <textarea class="form-control" name="announcement_content" rows="8"><?php echo e($settings->announcement, false); ?></textarea>

                <small class="d-block">
                    <?php echo e(__('general.announcement_info'), false); ?>

                </small>
		          </div>
		        </div>

                <fieldset class="row mb-3">
                    <legend class="col-form-label col-sm-2 pt-0 text-lg-end"><?php echo e(__('general.type_announcement'), false); ?></legend>
                    <div class="col-sm-10">
                      <div class="form-check">
                        <input class="form-check-input" type="radio" name="type_announcement" id="radio1" <?php if($settings->type_announcement == 'primary'): ?> checked="checked" <?php endif; ?> value="primary" checked>
                        <label class="form-check-label" for="radio1">
                          <?php echo e(trans('general.informative'), false); ?>

                        </label>
                      </div>
                      <div class="form-check">
                        <input class="form-check-input" type="radio" name="type_announcement" id="radio2" <?php if($settings->type_announcement == 'danger'): ?> checked="checked" <?php endif; ?> value="danger">
                        <label class="form-check-label" for="radio2">
                          <?php echo e(trans('general.important'), false); ?>

                        </label>
                      </div>
                    </div>
                  </fieldset><!-- end row -->

						<fieldset class="row mb-3">
	                    <legend class="col-form-label col-sm-2 pt-0 text-lg-end"><?php echo e(__('general.show_announcement_to'), false); ?></legend>
	                    <div class="col-sm-10">
	                      <div class="form-check">
	                        <input class="form-check-input" type="radio" name="announcement_show" id="radio3" <?php if($settings->announcement_show == 'all'): ?> checked="checked" <?php endif; ?> value="all" checked>
	                        <label class="form-check-label" for="radio3">
	                          <?php echo e(trans('general.all_users'), false); ?>

	                        </label>
	                      </div>
	                      <div class="form-check">
	                        <input class="form-check-input" type="radio" name="announcement_show" id="radio4" <?php if($settings->announcement_show == 'creators'): ?> checked="checked" <?php endif; ?> value="creators">
	                        <label class="form-check-label" for="radio4">
	                          <?php echo e(trans('general.only_creators'), false); ?>

	                        </label>
	                      </div>
	                    </div>
	                  </fieldset><!-- end row -->

						<div class="row mb-3">
		          <div class="col-sm-10 offset-sm-2">
		            <button type="submit" class="btn btn-dark mt-3 px-5"><?php echo e(__('admin.save'), false); ?></button>
		          </div>
		        </div>

		       </form>

				 </div><!-- card-body -->
 			</div><!-- card  -->
 		</div><!-- col-lg-12 -->

	</div><!-- end row -->
</div><!-- end content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\app\resources\views/admin/announcements.blade.php ENDPATH**/ ?>