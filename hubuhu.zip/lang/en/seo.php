<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| SEO Language Lines
	|--------------------------------------------------------------------------
	|
	*/
	"slogan" => "Create Page or Ad", // New on v4.0
	"description" => "Grow your Business.",
	"keywords" => "Business,support,creators,Page,subscription,content,advertise,boost,promote",
);
