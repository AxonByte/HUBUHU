<style>
    #liveStreamingForm .nav-tabs .nav-item.show .nav-link, .nav-tabs .nav-link.active {
        color: #ffffff;
        background-color: #000000;
        border-color: #dee2e6 #dee2e6 #fff;
    }
    .text-center.d-flex.gap-2 > button {
        margin: 0 5px;
    }

    #map {
    border: 1px solid #ddd;
    border-radius: 10px;
    margin-bottom: 15px;
}

/* Optional: Remove arrow for IE (legacy fallback) */
#select_goal::-ms-expand {
    display: none;
}

#select_goal {
    border: 1px solid #ccc;
    border-radius: 6px;
    appearance: none;           /* Removes default arrow in modern browsers */
    -webkit-appearance: none;
    -moz-appearance: none;
    padding-right: 30px;        /* Add space to compensate for hidden arrow */
    background-image: none;     /* Remove default arrow background */
}

.pac-container {
        z-index: 1051 !important; /* Higher than .modal's z-index (usually 1050) */
    }

/* WhatsApp input group */
.custom-whatsapp-group {
    display: flex;
    align-items: center;
    border: 1px solid #ccc;
    border-radius: 8px;
    background-color: #f5f5f5;
    padding: 0;
    overflow: hidden;
    position: relative;
}

#autocomplete.select2-hidden-accessible + .select2-container {
  display: block !important;
}


/* Country code dropdown */
.country-select {
    border: none;
    background-color: #f5f5f5;
    padding: 12px 10px;
    font-size: 14px;
    width: 100px;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    border-right: 1px solid #ccc;
}

/* WhatsApp input */
.whatsapp-input {
    border: none;
    background-color: #f5f5f5;
    padding: 12px 12px 12px 10px;
    font-size: 14px;
    flex: 1;
}

/* Icon inside input */
.whatsapp-icon {
    padding: 0 12px;
    color: #25D366;
    font-size: 18px;
}

/* Focus styles */
.country-select:focus,
.whatsapp-input:focus {
    outline: none;
    box-shadow: none;
    background-color: #fefefe;
}


#uploadPreviewBox {
    height: 300px;
    border: 2px dashed #ccc;
    border-radius: 10px;
    background-color: #e0e0e0;
    color: #999;
    font-size: 14px;
    text-align: center;
    overflow: hidden;
    position: relative;
}


#uploadPreviewBox img,
#uploadPreviewBox video {
    width: 100%;
    height: 100%;
    object-fit: contain;
}
#removeMediaBtn {
    border-color: #000000 !important;
    border-radius: 0 !important;
    width: 28px;
    height: 28px;
    padding: 0;
    text-align: center;
    line-height: 20px;
    font-weight: bold;
}

#radiusRange {
    width: 100%;
}
#radiusValue {
    font-weight: 600;
}

.map-control {
    position: absolute;
    bottom: 10px;
    left: 10px;
    background: white;
    padding: 12px;
    border-radius: 8px;
    z-index: 5;
    width: 350px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    font-size: 16px;
}


#toggleSearch {
    width: 45px;
    height: 45px;
    border-radius: 0 !important;
    background: #fff;
    padding: 8px; /* NOT 32px — that was oversized */
    display: flex;
    justify-content: center;
    align-items: center;
}


 /* Apply to all form-controls in goal section */

    #whatsappInputContainer select,
    #whatsappInputContainer input,
    #sendMessageInputContainer input,
    #visitNowInputContainer input,
    #buyNowInputContainer input,
    #orderNowInputContainer input,
    #startNowInputContainer input,
    #installNowInputContainer input,
    #learnMoreInputContainer input {
        background-color: #f5f5f5 !important;
        border: 1px solid #ccc !important;
        color: #333;
        font-size: 14px;
    }

    /* Optional: Remove focus outline */
    #whatsappInputContainer select:focus,
    #whatsappInputContainer input:focus,
    #sendMessageInputContainer input:focus,
    #visitNowInputContainer input:focus,
    #buyNowInputContainer input:focus,
    #orderNowInputContainer input:focus,
    #startNowInputContainer input:focus,
    #installNowInputContainer input:focus,
    #learnMoreInputContainer input:focus {
        box-shadow: none;
        outline: none;
    }
    .radius-label {
        min-width: 45px;
        font-weight: 600;
        padding-top: 6px;
    }

    .is-invalid {
        border: 1px solid #dc3545 !important;
    }

    .map_input {
        top: 10px;
        z-index: 999;
        width: 100%;  /* Use percentage instead of vh for full width */
        padding: 0 10px; /* Optional padding */
        left: 0;
        right: 0;
    }

    
    .select2-error-highlight {
        border: 2px solid red !important;
        border-radius: 4px;
        }

    #mapControls .select2-container {
        display: block !important;
    }

    .map_input input {
        width: 100%;
    }

    .pac-container:after {
        background-image: none !important;
        height: 0px;
    }

    @media (max-width: 576px) {
        #mapRadiusControl{
             width: 100%;
            padding: 0 10px; /* Optional padding */
            left: 0;
            right: 0;
        }
    }
  
.gm-style > div > div > a > div > img {
    display: none;
}


a[title="Report errors in the road map or imagery to Google"] {
    display: none !important;
}
</style>
<!-- Bootstrap Icons CDN (include in <head> or before </body>) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

<!-- Start Modal liveStreamingForm -->
<div class="modal fade" id="liveStreamingForm" tabindex="-1" role="dialog" aria-labelledby="modal-form"
     aria-hidden="true">
    <div class="modal-dialog modal- modal-dialog-centered " role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="card bg-white shadow border-0">

                    <div class="card-body px-lg-5 py-lg-5 position-relative">
                        <form method="post" action="{{url('create/live')}}" id="formSendLive">
                            <div class="mb-3">
                            <button type="button"
                                data-dismiss="modal"aria-label="Close"
                                    style="position: absolute; top: 15px; right: 15px; background: transparent; border: none; font-size: 2rem; line-height: 1; color: #000;">
                                &times;
                            </button>
                            </div>

                            @csrf
                            <div class="text-center mb-4">
                                <ul class="nav nav-tabs justify-content-center" id="modeTabs" role="tablist" style="border: none;">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="tab-review" type="button" role="tab">Start Earning</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="tab-boost" type="button" role="tab"><i class="fa fa-edit" style="color:#555"></i> Advertise</button>
                                    </li>
                                </ul>
                                <input type="hidden" name="mode" id="modeInput" value="review">
                            </div>

                            
                            
                            <div id="categorySection">
                                <div class="form-group">
                                    <div class="input-group mb-4">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"><i class="bi bi-lightning-charge"></i></span>
                                        </div>
                                        <input type="text" autocomplete="off" class="form-control" name="name"
                                            placeholder="{{ __('auth.title') }} *">
                                    </div>
                                </div><!-- End form-group -->
                                <div class="form-group mb-3" >
                                    @php
                                        $categoriesLoc = isset($liveStreamsCategories) ? $liveStreamsCategories : [];
                                    @endphp
                                    <select  id="filterLocationUser" name="locationUser[]" multiple class="form-control categoriesMultiple">
                                        @foreach ($categoriesLoc as $category)
                                            <option value="{{$category}}">{{$category}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            <div class="form-group">
                                <label class="sr-only" for="category">{{ __('Category') }}</label>
                                <div class="d-flex flex-wrap justify-content-start category-grid">
                                    @php
                                        $categories = ['Buysell', 'Job', 'To-let'];
                                    @endphp
                                    @foreach ($categories as $category)
                                        <input type="radio" class="btn-check d-none" name="category" id="cat_{{ strtolower($category) }}" value="{{ strtolower($category) }}">
                                        <label for="cat_{{ strtolower($category) }}" class="category-box text-center">
                                            {{ $category }}
                                        </label>
                                    @endforeach
                                </div>
                            </div>
                            </div>

                            <div class="form-group d-none">
                                <div class="input-group mb-2" id="AvailabilityGroup">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="bi bi-eye"></i></span>
                                    </div>
                                    <select name="availability" id="Availability" class="form-control custom-select">
                                        <option value="all_pay"
                                                data-text="{{ trans('general.desc_available_everyone_paid') }}">{{trans('general.available_everyone_paid')}}</option>
                                        <option value="free_paid_subscribers"
                                                data-text="{{ trans('general.info_price_live') }}">{{trans('general.available_free_paid_subscribers')}}</option>

                                        @if ($settings->live_streaming_free)
                                            <option value="everyone_free"
                                                    data-text="{{ trans('general.desc_everyone_free') }}">{{trans('general.available_everyone_free')}}</option>
                                        @endif
                                    </select>
                                </div>

                                @if ($settings->limit_live_streaming_paid != 0)
                                    <small class="form-text text-danger" id="LimitLiveStreamingPaid">
                                        <i class="bi bi-exclamation-triangle-fill mr-1"></i>
                                        <strong>{{ trans('general.limit__minutes_per_transmission_paid', ['min' => $settings->limit_live_streaming_paid]) }}</strong>
                                    </small>
                                @endif

                                @if ($settings->limit_live_streaming_free != 0)
                                    <small class="form-text display-none text-danger" id="everyoneFreeAlert">
                                        <i class="bi bi-exclamation-triangle-fill mr-1"></i>
                                        <strong>{{ trans('general.limit__minutes_per_transmission_free', ['min' => $settings->limit_live_streaming_free]) }}</strong>
                                    </small>
                                @endif

                            </div><!-- ./form-group -->
                            <div class="text-center">
                                <button id="publishBtn" class="btn btn-primary  mt-4">
                                <i></i> Publish
                            </button>
                            </div>
                        </form>

                        <form method="POST" id="advertise_save" action="{{ route('save.advertise.request') }}">
                            @csrf
                            <div id="boostSection">
                                <div id="boostStep1">
                                    <div class="form-group">
                                        <div class="input-group mb-4">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="bi bi-lightning-charge"></i></span>
                                            </div>
                                            <input type="text" autocomplete="off" class="form-control" id="adTitle" name="name"
                                                placeholder="{{ __('auth.title') }} *">
                                        </div>
                                    </div><!-- End form-group -->
                                    
                                   
                                    <div class="form-group mb-3 position-relative" id="mapWrapper" >
                                        <!-- Search Input + Pin Icon -->
                                        
                                        


                                        <div id="mapControls"
                                            style="position: absolute; top: 10px; left: 10px; right: 10px; z-index: 9999;">
                                            <select id="locationsSelect2" class="form-control w-100" multiple="multiple" name="adlocations[]"></select>
                                        </div>
                                        
                                        <!-- Map -->
                                        <div id="map" style="width: 100%; height: 400px; margin-top: 20px;"></div>
                                        <!-- Radius Slider -->
                                        <div id="mapRadiusControl"
                                            class="map-control d-flex align-items-center shadow-sm"
                                            style="position: absolute; bottom: 10px; left: 10px; z-index: 999; background: #fff; padding: 5px 10px; border-radius: 6px;">
                                            <label for="radiusRange" class="radius-label me-2">
                                                <span id="radiusValue">3</span> km
                                            </label>
                                            <input type="range" class="form-range flex-grow-1" id="radiusRange" name="address_range" min="1" max="20" value="3">
                                        </div>
                                    </div>
                                    <div class="form-group mb-3">
                                        <select id="select_goal" name="select_goal" class="form-control categoriesMultiple">
                                            <option value="">Select Goal</option>
                                            <option value="send_message">&#128172; Send message</option>
                                            <option value="visit_now">&#127970; Visit now</option>
                                            <option value="buy_now">&#128179; Buy now</option>
                                            <option value="order_now">&#128717; Order now</option>
                                            <option value="start_now">&#128640; Start now</option>
                                            <option value="install_now">&#128187; Install now</option>
                                            <option value="learn_more">&#128214; Learn more</option>
                                            <option value="chat_on_whatsapp">&#128241; Chat on WhatsApp</option>
                                        </select>
                                        <!-- Shown only when WhatsApp option is selected -->
                                        <div id="whatsappInputContainer" class="form-group d-none">
                                            <div class="input-group">
                                                <select class="form-select" style="max-width: 120px;" name="country_code" id="country_code">
                                                    <option value="+91">+91</option>
                                                    <option value="+880">+880</option>
                                                    <option value="+1">+1</option>
                                                    <option value="+92">+92</option>                                                
                                                </select>
                                                <input type="text" class="form-control" id="whatsapp_number" name="whatsapp_number" placeholder="Enter WhatsApp Number">
                                            </div>
                                            <div id="whatsappError" class="invalid-feedback d-none">
                                                Please enter a valid 10-digit WhatsApp number.
                                            </div>
                                        </div>
                                        <div id="sendMessageInputContainer" class="form-group d-none">
                                            <input type="text" class="form-control" id="send_message" name="send_message" placeholder="Send Message">
                                        </div>
                                        <div id="visitNowInputContainer" class="form-group d-none">
                                            <input type="text" class="form-control" id="visit_now" name="visit_now" placeholder="Enter Url">
                                        </div>
                                        <div id="buyNowInputContainer" class="form-group d-none">
                                            <input type="text" class="form-control" id="buy_now" name="buy_now" placeholder="Enter Url">
                                        </div>
                                        <div id="orderNowInputContainer" class="form-group d-none">
                                            <input type="text" class="form-control" id="order_now" name="order_now" placeholder="Enter Url">
                                        </div>
                                        <div id="startNowInputContainer" class="form-group d-none">
                                            <input type="text" class="form-control" id="start_now" name="start_now" placeholder="Enter Url">
                                        </div>
                                        <div id="installNowInputContainer" class="form-group d-none">
                                            <input type="text" class="form-control" id="install_now" name="install_now" placeholder="Enter Url">
                                        </div>
                                        <div id="learnMoreInputContainer" class="form-group d-none">
                                            <input type="text" class="form-control" id="learn_more" name="learn_more" placeholder="Enter Url">
                                        </div>
                                    </div>
                                </div>
                                <div id="boostStep2" class="d-none">
                                     <div class="form-group mb-3">
                                        <textarea id="goal_description" name="goal_description" class="form-control" rows="3" placeholder="Ad Description" required></textarea>
                                        <div class="invalid-feedback" id="errorGoalDesc"></div>
                                    </div>
                                    <!-- Upload Preview Box -->
                                    <div class="form-group mb-3">
                                        <div class="position-relative">
                                            <div id="uploadPreviewBox" class="d-flex align-items-center justify-content-center">
                                                <span class="text-muted text-center">Upload Ad<br><small>Ad will preview here</small></span>
                                            </div>
                                            <button type="button" id="removeMediaBtn" class="btn btn-sm  position-absolute" 
                                                style="top: 10px; right: 10px; display: none; z-index: 10;">X</button>
                                            <input type="file" id="mediaUpload" name="ad_media" accept="image/*,video/*" class="form-control mt-2" required>
                                            <div class="invalid-feedback d-block" id="errorMediaUpload"></div>
                                        </div>                                        
                                    </div>
                                    <div class="form-group mb-0">
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">{{$settings->currency_symbol}}</span>
                                            </div>
                                            <input type="number" min="{{$settings->live_streaming_minimum_price}}"
                                                value="{{$settings->live_streaming_minimum_price}}"
                                                autocomplete="off" id="adPrice" class="form-control priceLive"
                                                name="price" required
                                                placeholder="{{ __('general.budget') }}">
                                                <div class="invalid-feedback" id="errorPrice"></div>
                                        </div>
                                    </div><!-- End form-group -->
                                    
                                </div>
                                
                            </div>
                            <small class="form-text mb-3" style="font-size:11px"
                                   id="descAvailability">By clicking, you agree to Hubuhu's Terms & conditions.</small>

                            <div class="alert alert-danger display-none mb-0 mt-3" id="errorLive">
                                <ul class="list-unstyled m-0" id="showErrorsLive"></ul>
                            </div>
                            <div class="text-center justify-content-center gap-3 mt-3">
                                <button type="button" id="nextStepBtn" class="btn btn-primary">Next</button>
                                <button type="button" id="backStepBtn" class="btn btn-outline-secondary mt-4">Back</button>
                                <button id="createAdBtn" class="btn btn-primary mt-4 d-none" type="button">
                                    <span class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true" id="createAdSpinner"></span>
                                    <span id="createAdBtnText">Create Ad</span>
                                </button>


                            </div>             
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- End Modal liveStreamingForm -->


<!-- Start Modal CategoryForm -->
<div class="modal fade" id="CategoryForm" tabindex="-1" role="dialog" aria-labelledby="modal-form"
    aria-hidden="true">
    <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="card bg-white shadow border-0">
                    <div class="card-body px-lg-5 py-lg-5 position-relative">
                        <div class="mb-3">
                            <i class="bi bi-broadcast mr-1"></i>
                            <strong>Review Filter</strong>
                        </div>
                        <div class="form-group mb-3" >
                            @php
                                $categoriesLoc = isset($liveStreamsCategories) ? $liveStreamsCategories : [];
                            @endphp
                            <select  id="filterLocation" name="location[]" multiple class="form-control categoriesMultiple">
                                @foreach ($categoriesLoc as $category)
                                    <option value="{{$category}}">{{$category}}</option>
                                @endforeach
                            </select>
                        </div>
                            <div class="form-group">
                                <label class="sr-only" for="category">{{ __('Category') }}</label>
                                <div class="d-flex flex-wrap justify-content-start category-grid">
                                    @php
                                        $categories = ['Buysell', 'Job', 'To-let'];
                                    @endphp
                                    @foreach ($categories as $category)
                                        <input type="radio" class="btn-check d-none" name="category" id="cat_{{ strtolower($category) }}"
                                            value="{{ strtolower($category) }}">
                                        <label for="cat_{{ strtolower($category) }}" class="category-box text-center" onclick="labelToggleClick(this)">
                                            {{ $category }}
                                        </label>
                                    @endforeach
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="button" class="btn e-none mt-4"
                                    data-dismiss="modal">{{trans('admin.cancel')}}</button>
                                <button type="submit" id="applyCategoryFilter" class="btn btn-primary mt-4">
                                    <i></i> {{trans('users.filter')}}</button>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- End Modal CategoryForm -->

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCy7F3rkXNkbaCAou5KtqEMWnuQTE2bWtE&libraries=places"></script>
<script>
  let map;
  let markers = [];
  let cityCountryMarkers = [];
  let addressMarkers = [];

  let cityCountryCircles = [];
  let addressCircles = [];

  let defaultMarker = null;
  let defaultCircle = null;
  let currentRadiusKm = 3;

  function initMap() {
    const defaultLocation = { lat: 23.8103, lng: 90.4125 }; // Dhaka

    map = new google.maps.Map(document.getElementById("map"), {
      center: defaultLocation,
      zoom: 12,
      streetViewControl: false,
      mapTypeControl: false,
      fullscreenControl: false,
      zoomControl: true
    });

    defaultMarker = new google.maps.Marker({
      map: map,
      position: defaultLocation,
      draggable: true
    });

    defaultCircle = new google.maps.Circle({
      map: map,
      radius: currentRadiusKm * 1000,
      fillColor: '#FF0000',
      fillOpacity: 0.3,
      strokeColor: '#FF0000',
      strokeOpacity: 0.5,
      strokeWeight: 1
    });
    defaultCircle.bindTo('center', defaultMarker, 'position');

    defaultMarker.addListener("dragend", function () {
      map.panTo(defaultMarker.getPosition());
    });

    $('#locationsSelect2').select2({
      placeholder: "Search locations",
      minimumInputLength: 3,
      ajax: {
        transport: function (params, success, failure) {
          const input = params.data.q;
          const service = new google.maps.places.AutocompleteService();
          service.getPlacePredictions({ input: input }, success);
        },
        processResults: function (data) {
          return {
            results: data.map(prediction => ({
              id: prediction.place_id,
              text: prediction.description
            }))
          };
        }
      }
    });

    $('#locationsSelect2').on('select2:select', function (e) {
      const placeId = e.params.data.id;
      const geocoder = new google.maps.Geocoder();

      geocoder.geocode({ placeId: placeId }, function (results, status) {
        if (status === 'OK') {
          const result = results[0];
          const location = result.geometry.location;

          const placeTypes = result.types;

          let isCityCountry = placeTypes.includes('country') || placeTypes.includes('locality');
          let radiusMeters = currentRadiusKm * 1000;

          if (isCityCountry && result.geometry.viewport) {
            const bounds = result.geometry.viewport;
            const ne = bounds.getNorthEast();
            const sw = bounds.getSouthWest();
            const latDiff = ne.lat() - sw.lat();
            const lngDiff = ne.lng() - sw.lng();
            const approxDiameterKm = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111;
            radiusMeters = (approxDiameterKm / 2) * 1000;
          }

          // Hide default if anything is selected
          defaultMarker.setMap(null);
          defaultCircle.setMap(null);

          const marker = new google.maps.Marker({
            map: map,
            position: location,
            draggable: true
          });

          const circle = new google.maps.Circle({
            map: map,
            radius: radiusMeters,
            fillColor: '#FF0000',
            fillOpacity: 0.3,
            strokeColor: '#FF0000',
            strokeOpacity: 0.5,
            strokeWeight: 1
          });
          circle.bindTo('center', marker, 'position');

          if (isCityCountry) {
            cityCountryMarkers.push(marker);
            cityCountryCircles.push(circle);
          } else {
            addressMarkers.push(marker);
            addressCircles.push(circle);
          }

          // Pan or fit
          if (isCityCountry && result.geometry.viewport) {
            map.fitBounds(result.geometry.viewport);
          } else {
            map.panTo(location);
          }

          marker.addListener("dragend", function () {
            map.panTo(marker.getPosition());
          });

          // Enable slider if ANY address circle exists
          document.getElementById('radiusRange').disabled = addressCircles.length === 0;
        }
      });
    });

    $('#locationsSelect2').on('select2:unselect', function (e) {
      const geocoder = new google.maps.Geocoder();
      const selectedPlaceIds = $('#locationsSelect2').val() || [];

      // Clear everything
      cityCountryMarkers.forEach(m => m.setMap(null));
      cityCountryCircles.forEach(c => c.setMap(null));
      addressMarkers.forEach(m => m.setMap(null));
      addressCircles.forEach(c => c.setMap(null));

      cityCountryMarkers = [];
      cityCountryCircles = [];
      addressMarkers = [];
      addressCircles = [];

      if (selectedPlaceIds.length === 0) {
        defaultMarker.setMap(map);
        defaultCircle.setMap(map);
        map.panTo(defaultMarker.getPosition());
        document.getElementById('radiusRange').disabled = false;
      } else {
        selectedPlaceIds.forEach(pid => {
          geocoder.geocode({ placeId: pid }, function (results, status) {
            if (status === 'OK') {
              const result = results[0];
              const location = result.geometry.location;

              const placeTypes = result.types;

              let isCityCountry = placeTypes.includes('country') || placeTypes.includes('locality');
              let radiusMeters = currentRadiusKm * 1000;

              if (isCityCountry && result.geometry.viewport) {
                const bounds = result.geometry.viewport;
                const ne = bounds.getNorthEast();
                const sw = bounds.getSouthWest();
                const latDiff = ne.lat() - sw.lat();
                const lngDiff = ne.lng() - sw.lng();
                const approxDiameterKm = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111;
                radiusMeters = (approxDiameterKm / 2) * 1000;
              }

              const marker = new google.maps.Marker({
                map: map,
                position: location,
                draggable: true
              });

              const circle = new google.maps.Circle({
                map: map,
                radius: radiusMeters,
                fillColor: '#FF0000',
                fillOpacity: 0.3,
                strokeColor: '#FF0000',
                strokeOpacity: 0.5,
                strokeWeight: 1
              });
              circle.bindTo('center', marker, 'position');

              if (isCityCountry) {
                cityCountryMarkers.push(marker);
                cityCountryCircles.push(circle);
              } else {
                addressMarkers.push(marker);
                addressCircles.push(circle);
              }

              if (isCityCountry && result.geometry.viewport) {
                map.fitBounds(result.geometry.viewport);
              } else {
                map.panTo(location);
              }

              marker.addListener("dragend", function () {
                map.panTo(marker.getPosition());
              });

              document.getElementById('radiusRange').disabled = addressCircles.length === 0;
            }
          });
        });
      }
    });

    // --- Radius slider only updates address circles ---
    document.getElementById('radiusRange').addEventListener('input', function () {
      currentRadiusKm = parseInt(this.value);
      document.getElementById('radiusValue').textContent = currentRadiusKm;

      addressCircles.forEach(circle => {
        circle.setRadius(currentRadiusKm * 1000);
      });

      if (cityCountryCircles.length === 0 && addressCircles.length === 0) {
        defaultCircle.setRadius(currentRadiusKm * 1000);
      }
    });
  }

  document.addEventListener("DOMContentLoaded", initMap);
</script>

<!-- <script>
  let map;
  let markers = [];
  let circles = [];
  let defaultMarker = null;
  let defaultCircle = null;
  let currentRadiusKm = 3;

  function initMap() {
    const defaultLocation = { lat: 23.8103, lng: 90.4125 }; // Dhaka

    map = new google.maps.Map(document.getElementById("map"), {
      center: defaultLocation,
      zoom: 12,
      streetViewControl: false,
      mapTypeControl: false,
      fullscreenControl: false,
      zoomControl: true
    });

    // --- Initialize default marker & circle ---
    defaultMarker = new google.maps.Marker({
      map: map,
      position: defaultLocation,
      draggable: true
    });

    defaultCircle = new google.maps.Circle({
      map: map,
      radius: currentRadiusKm * 1000,
      fillColor: '#FF0000',
      fillOpacity: 0.3,
      strokeColor: '#FF0000',
      strokeOpacity: 0.5,
      strokeWeight: 1
    });
    defaultCircle.bindTo('center', defaultMarker, 'position');

    // If user drags default marker
    defaultMarker.addListener("dragend", function () {
      map.panTo(defaultMarker.getPosition());
    });

    // --- Initialize Select2 ---
    $('#locationsSelect2').select2({
      placeholder: "Search locations",
      minimumInputLength: 3,
      ajax: {
        transport: function (params, success, failure) {
          const input = params.data.q;
          const service = new google.maps.places.AutocompleteService();
          service.getPlacePredictions({ input: input }, success);
        },
        processResults: function (data) {
          return {
            results: data.map(prediction => ({
              id: prediction.place_id,
              text: prediction.description
            }))
          };
        }
      }
    });

    // --- When a place is selected ---
    $('#locationsSelect2').on('select2:select', function (e) {
      const placeId = e.params.data.id;

      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ placeId: placeId }, function (results, status) {
        if (status === 'OK') {
          const location = results[0].geometry.location;

          // Hide default marker & circle
          defaultMarker.setMap(null);
          defaultCircle.setMap(null);

          const marker = new google.maps.Marker({
            map: map,
            position: location,
            draggable: true
          });
          markers.push(marker);

          const circle = new google.maps.Circle({
            map: map,
            radius: currentRadiusKm * 1000,
            fillColor: '#FF0000',
            fillOpacity: 0.3,
            strokeColor: '#FF0000',
            strokeOpacity: 0.5,
            strokeWeight: 1
          });
          circle.bindTo('center', marker, 'position');
          circles.push(circle);

          map.panTo(location);

          marker.addListener("dragend", function () {
            map.panTo(marker.getPosition());
          });
        }
      });
    });

    // --- When a place is unselected ---
    $('#locationsSelect2').on('select2:unselect', function (e) {
      // Remove all existing selected markers/circles
      markers.forEach(marker => marker.setMap(null));
      circles.forEach(circle => circle.setMap(null));
      markers = [];
      circles = [];

      const selectedPlaceIds = $('#locationsSelect2').val() || [];
      const geocoder = new google.maps.Geocoder();

      if (selectedPlaceIds.length === 0) {
        // ✅ If no locations, show default again
        defaultMarker.setMap(map);
        defaultCircle.setMap(map);
        map.panTo(defaultMarker.getPosition());
      } else {
        selectedPlaceIds.forEach(pid => {
          geocoder.geocode({ placeId: pid }, function (results, status) {
            if (status === 'OK') {
              const location = results[0].geometry.location;

              const marker = new google.maps.Marker({
                map: map,
                position: location,
                draggable: true
              });
              markers.push(marker);

              const circle = new google.maps.Circle({
                map: map,
                radius: currentRadiusKm * 1000,
                fillColor: '#FF0000',
                fillOpacity: 0.3,
                strokeColor: '#FF0000',
                strokeOpacity: 0.5,
                strokeWeight: 1
              });
              circle.bindTo('center', marker, 'position');
              circles.push(circle);

              marker.addListener("dragend", function () {
                map.panTo(marker.getPosition());
              });
            }
          });
        });
      }
    });

    // --- Radius slider ---
    document.getElementById('radiusRange').addEventListener('input', function () {
      currentRadiusKm = parseInt(this.value);
      document.getElementById('radiusValue').textContent = currentRadiusKm;

      // Update all selected circles
      circles.forEach(circle => {
        circle.setRadius(currentRadiusKm * 1000);
      });

      // If no locations, update default circle too
      if (markers.length === 0) {
        defaultCircle.setRadius(currentRadiusKm * 1000);
      }
    });
  }

  document.addEventListener("DOMContentLoaded", initMap);
 
</script> -->



<script>
document.addEventListener('DOMContentLoaded', function () {
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

    const createAdBtn = document.getElementById('createAdBtn');
    const createAdSpinner = document.getElementById('createAdSpinner');
    const createAdBtnText = document.getElementById('createAdBtnText');

    const goalDescInput = document.getElementById('goal_description');
    const adMediaInput = document.getElementById('mediaUpload');
    const priceInput = document.getElementById('adPrice');

    const errorGoalDesc = document.getElementById('errorGoalDesc');
    const errorMedia = document.getElementById('errorMediaUpload');
    const errorPrice = document.getElementById('errorPrice');

    function clearErrors() {
        [goalDescInput, adMediaInput, priceInput].forEach(el => el.classList.remove('is-invalid'));
        [errorGoalDesc, errorMedia, errorPrice].forEach(el => el.textContent = '');
    }

    function setLoadingState(isLoading) {
        if (isLoading) {
            createAdBtn.setAttribute('disabled', 'disabled');
            createAdSpinner.classList.remove('d-none');
            createAdBtnText.textContent = 'Creating...';
        } else {
            createAdBtn.removeAttribute('disabled');
            createAdSpinner.classList.add('d-none');
            createAdBtnText.textContent = 'Create Ad';
        }
    }

    createAdBtn.addEventListener('click', function (e) {
    e.preventDefault();
    clearErrors();
    setLoadingState(true);

    const form = document.getElementById('advertise_save');
    const formData = new FormData(form);

    // 🗺️ === ADD LOCATION DATA ===
    // Remove any old lat/lng fields if any
    formData.delete('latitudes[]');
    formData.delete('longitudes[]');
    formData.delete('types[]');

    // For city/country markers
    cityCountryMarkers.forEach(marker => {
        const pos = marker.getPosition();
        formData.append('latitudes[]', pos.lat());
        formData.append('longitudes[]', pos.lng());
        formData.append('types[]', 'cityCountry');
    });

    // For address markers
    addressMarkers.forEach(marker => {
        const pos = marker.getPosition();
        formData.append('latitudes[]', pos.lat());
        formData.append('longitudes[]', pos.lng());
        formData.append('types[]', 'address');
    });

    // If no markers, use default marker
    if (cityCountryMarkers.length === 0 && addressMarkers.length === 0 && defaultMarker) {
        const pos = defaultMarker.getPosition();
        formData.append('latitudes[]', pos.lat());
        formData.append('longitudes[]', pos.lng());
        formData.append('types[]', 'default');
    }

    // Also append final radius (already there, but safe)
    formData.set('address_range', currentRadiusKm);

    // === VALIDATION (same as yours)
    const goalDescription = goalDescInput.value.trim();
    const adMedia = adMediaInput.files[0];
    const price = priceInput.value;

    let hasError = false;

    if (!goalDescription) {
        goalDescInput.classList.add('is-invalid');
        errorGoalDesc.textContent = 'Ad description is required.';
        hasError = true;
    }

    if (!adMedia) {
        adMediaInput.classList.add('is-invalid');
        errorMedia.textContent = 'Ad media file is required.';
        hasError = true;
    }

    if (!price || isNaN(price) || parseFloat(price) <= 0) {
        priceInput.classList.add('is-invalid');
        errorPrice.textContent = 'Valid budget/price is required.';
        hasError = true;
    }

    if (hasError) {
        setLoadingState(false);
        return;
    }

    // === SUBMIT
    fetch("{{ route('save.advertise.request') }}", {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': csrfToken
        },
        body: formData
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => {
                throw new Error(err.message || 'Something went wrong!');
            });
        }
        return response.json();
    })
    .then(data => {
        alert('Ad submitted successfully');
        location.reload();
    })
    .catch(error => {
        alert(error.message);
        setLoadingState(false);
    });
});

});
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const goalSelector = document.getElementById('select_goal');

        const inputContainers = {
            send_message: document.getElementById('sendMessageInputContainer'),
            visit_now: document.getElementById('visitNowInputContainer'),
            buy_now: document.getElementById('buyNowInputContainer'),
            order_now: document.getElementById('orderNowInputContainer'),
            start_now: document.getElementById('startNowInputContainer'),
            install_now: document.getElementById('installNowInputContainer'),
            learn_more: document.getElementById('learnMoreInputContainer'),
            chat_on_whatsapp: document.getElementById('whatsappInputContainer'),
        };

        goalSelector.addEventListener('change', function () {
            const selectedValue = this.value;

            // Hide all first
            for (const key in inputContainers) {
                if (inputContainers[key]) {
                    inputContainers[key].classList.add('d-none');
                }
            }

            // Show selected
            if (inputContainers[selectedValue]) {
                inputContainers[selectedValue].classList.remove('d-none');
            }
        });
    });
</script>
<script> 
    const mediaUpload = document.getElementById("mediaUpload");
    const previewBox = document.getElementById("uploadPreviewBox");
    const removeBtn = document.getElementById("removeMediaBtn");

    const maxImageSize = 5 * 1024 * 1024; // 5MB
    const maxVideoSize = 10 * 1024 * 1024; // 10MB

    const allowedImageTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
    const allowedVideoTypes = ['video/mp4', 'video/webm'];

    function resetPreviewBox() {
        previewBox.innerHTML = "<span class='text-muted text-center'>Upload Ad<br><small>Ad will preview here</small></span>";
        removeBtn.style.display = "none";
        mediaUpload.value = "";
    }

    mediaUpload.addEventListener("change", function (e) {
        const file = e.target.files[0];
        previewBox.innerHTML = "";

        if (!file) {
            resetPreviewBox();
            return;
        }

        const fileType = file.type;
        const fileSize = file.size;

        let element;

        if (allowedImageTypes.includes(fileType)) {
            if (fileSize > maxImageSize) {
                previewBox.innerHTML = "<span class='text-danger'>Image size must be under 5MB.</span>";
                resetAfterDelay();
                return;
            }

            element = document.createElement("img");
            element.src = URL.createObjectURL(file);
            element.style.maxWidth = "100%";

        } else if (allowedVideoTypes.includes(fileType)) {
            if (fileSize > maxVideoSize) {
                previewBox.innerHTML = "<span class='text-danger'>Video size must be under 10MB.</span>";
                resetAfterDelay();
                return;
            }

            element = document.createElement("video");
            element.src = URL.createObjectURL(file);
            element.controls = true;
            element.style.maxWidth = "100%";

        } else {
            previewBox.innerHTML = "<span class='text-danger'>Unsupported file type.</span>";
            resetAfterDelay();
            return;
        }

        previewBox.appendChild(element);
        removeBtn.style.display = "block";
    });

    removeBtn.addEventListener("click", function () {
        resetPreviewBox();
    });

    function resetAfterDelay() {
        setTimeout(() => {
            resetPreviewBox();
        }, 2500);
    }
</script>


<style>
    .category-grid {
        max-width: 330px; /* Controls overall width of the grid */
    }

    .category-box {
        background-color: #f5f5f5;
        color: #666;
        border-radius: 10px;
        cursor: pointer;
        border: 1px solid transparent;
        width: 32%; /* Exactly 3 in one row */
        text-align: center;
        transition: all 0.2s ease-in-out;
        padding:8px;
        margin:2px;
    }

    .btn-check:checked + .category-box{
        background-color: #007bff;
        color: #fff;
        border-color: #007bff;
        font-weight: 600;
    }

    .category-box.active {
        background-color: #007bff;
        color: #fff;
        border-color: #007bff;
        font-weight: 600;
    }

    .category-box:hover {
        background-color: #e9ecef;
    }

</style>


<script>
    function labelToggleClick(element) {
        const forAttr = element.getAttribute('for');

        document.querySelectorAll('.category-box').forEach(label => {
            label.classList.remove('active');
        });

        element.classList.add('active');

        document.getElementById(forAttr).checked = true;

        console.log(`Selected category: ${document.querySelector('input[name="category"]:checked').value}`);
        console.log('Selected categories:', $('#filterLocation').val());
    }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const tabReview = document.getElementById('tab-review');
        const tabBoost = document.getElementById('tab-boost');
        const modeInput = document.getElementById('modeInput');

        const priceInput = document.getElementById('onlyNumber');
        const submitBtn = document.getElementById('liveBtn');
        const nextStepBtn = document.getElementById('nextStepBtn');
        const backStepBtn = document.getElementById('backStepBtn');
        const boostSection = document.getElementById('boostSection');
        const boostStep1 = document.getElementById('boostStep1');
        const boostStep2 = document.getElementById('boostStep2');
        const categorySection = document.getElementById('categorySection');
        const publishBtn = document.getElementById('publishBtn');
        const createAdBtn = document.getElementById('createAdBtn');


        function updateButtons() {
            const isBoost = modeInput.value === 'boost';
            const inStep2 = !boostStep2.classList.contains('d-none');

            // Hide all buttons by default
             publishBtn.classList.add('d-none');
            createAdBtn.classList.add('d-none');
            nextStepBtn.classList.add('d-none');
            backStepBtn.classList.add('d-none');

            if (!isBoost) {
                // Show only Publish button for Start Earning
                 publishBtn.classList.remove('d-none');
            } else {
                if (inStep2) {
                    // Step 2: Show Back + Create Ad
                    backStepBtn.classList.remove('d-none');
                    createAdBtn.classList.remove('d-none');
                } else {
                    // Step 1: Show Next button
                    nextStepBtn.classList.remove('d-none');
                }
            }
        }

       
        function updateFormState() {
            const isBoost = modeInput.value === 'boost';
            boostSection.classList.toggle('d-none', !isBoost);
            categorySection.classList.toggle('d-none', isBoost);
            updateButtons();
        }

        function checkPrice() {
            if (modeInput.value === 'boost') {
                const price = parseFloat(priceInput.value);
                const isValid = !isNaN(price) && price >= 200;
                submitBtn.disabled = !isValid;
            } else {
                submitBtn.disabled = false;
            }
        }

        // Tab event listeners
        tabReview.addEventListener('click', function () {
            modeInput.value = 'review';
            tabReview.classList.add('active');
            tabBoost.classList.remove('active');
            boostStep1.classList.add('d-none');
            boostStep2.classList.add('d-none');
            updateFormState();
        });

        tabBoost.addEventListener('click', function () {
            modeInput.value = 'boost';
            tabBoost.classList.add('active');
            tabReview.classList.remove('active');
            boostStep1.classList.remove('d-none');
            boostStep2.classList.add('d-none');
            updateFormState();
        });

        nextStepBtn.addEventListener('click', function () {
            let isValid = true;

            const allInputs = document.querySelectorAll('#boostStep1 input, #boostStep1 select');
            allInputs.forEach(el => el.classList.remove('is-invalid'));
            $('.select2-selection').removeClass('select2-error-highlight');

            const nameInput = document.getElementById('adTitle');
            const locationsSelect = $('#locationsSelect2');
            const selectedLocations = locationsSelect.val();
            const goalSelect = document.querySelector('select[name="select_goal"]');
            const goalValue = goalSelect.value;
            

            if (!nameInput.value.trim()) {
                nameInput.classList.add('is-invalid');
                isValid = false;
            }

            if (!selectedLocations || selectedLocations.length === 0) {
                $('.select2-selection').first().addClass('select2-error-highlight');
                isValid = false;
            }

            if (!goalValue) {
                goalSelect.classList.add('is-invalid');
                isValid = false;
            }

            const goalInputs = {
                chat_on_whatsapp: document.getElementById('whatsapp_number'),
                send_message: document.getElementById('send_message'),
                visit_now: document.getElementById('visit_now'),
                buy_now: document.getElementById('buy_now'),
                order_now: document.getElementById('order_now'),
                start_now: document.getElementById('start_now'),
                install_now: document.getElementById('install_now'),
                learn_more: document.getElementById('learn_more'),
            };

            if (goalValue in goalInputs) {
                const input = goalInputs[goalValue];
                if (input) {
                    const inputVal = input.value.trim();
                    const errorDiv = document.getElementById('whatsappError');
                    if (goalValue === 'chat_on_whatsapp') {
                        // WhatsApp number: must be only digits and exactly 10 digits
                        const isNumeric = /^\d{10}$/.test(inputVal);
                        if (!isNumeric) {
                            input.classList.add('is-invalid');
                            alert("Please enter a valid 10-digit WhatsApp number");
                            isValid = false;
                        }
                    } else {
                        if (inputVal === '') {
                            input.classList.add('is-invalid');
                            isValid = false;
                        }
                    }
                }
            }


            if (!isValid) {
                return;
            }

            document.getElementById('boostStep1').classList.add('d-none');
            document.getElementById('boostStep2').classList.remove('d-none');
            updateButtons();
        });




        backStepBtn.addEventListener('click', function () {
            boostStep2.classList.add('d-none');
            boostStep1.classList.remove('d-none');
            updateButtons();
        });

        priceInput.addEventListener('input', checkPrice);

        updateFormState(); // Init
    });
</script>







