<div class="col-md-4 mb-4">
    <div class="card h-100" style="background-color: #e0e0e0; min-height: 350px;">
        <div class="card-body">
            <div class="d-flex flex-column justify-content-center align-items-center text-center h-100">
                <div class="mb-3">
                    <img src="{{ asset('storage/' . $business->logo ?? 'public/images/icons/shop.png') }}" alt="Business Logo" width="40">
                </div>
                <h5 class="card-title">{{ $business->name }}</h5>
                <p class="card-text text-muted">{{ $business->category->name ?? '' }}</p>
            </div>
        </div>
    </div>
</div>
