<!-- Start Modal liveStreamingForm -->
<div class="modal fade" id="liveStreamingForm" tabindex="-1" role="dialog" aria-labelledby="modal-form"
     aria-hidden="true">
    <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="card bg-white shadow border-0">

                    <div class="card-body px-lg-5 py-lg-5 position-relative">
                        <form method="post" action="{{url('create/live')}}" id="formSendLive">

                            <div class="mb-3">
                            <button type="button"
                                data-dismiss="modal"aria-label="Close"
                                    style="position: absolute; top: 15px; right: 15px; background: transparent; border: none; font-size: 2rem; line-height: 1; color: #000;">
                                &times;
                            </button>
                            </div>

                            @csrf
                            <div class="text-center mb-4">
                                <ul class="nav nav-tabs justify-content-center" id="modeTabs" role="tablist" style="border: none;">
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link active" id="tab-review" type="button" role="tab">Start Earning</button>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <button class="nav-link" id="tab-boost" type="button" role="tab"><i class="fa fa-edit" style="color:#555"></i> Advertise</button>
                                    </li>
                                </ul>
                                <input type="hidden" name="mode" id="modeInput" value="review">
                            </div>

                            <div class="form-group">
                                <div class="input-group mb-4">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="bi bi-lightning-charge"></i></span>
                                    </div>
                                    <input type="text" autocomplete="off" class="form-control" name="name"
                                           placeholder="{{ __('auth.title') }} *">
                                </div>
                            </div><!-- End form-group -->
                            <div class="form-group mb-3" >
                                @php
                                    $categoriesLoc = isset($liveStreamsCategories) ? $liveStreamsCategories : [];
                                @endphp
                                <select  id="filterLocationUser" name="locationUser[]" multiple class="form-control categoriesMultiple">
                                    @foreach ($categoriesLoc as $category)
                                        <option value="{{$category}}">{{$category}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div id="categorySection">
                            <div class="form-group">
                                <label class="sr-only" for="category">{{ __('Category') }}</label>
                                <div class="d-flex flex-wrap justify-content-start category-grid">
                                    @php
                                        $categories = ['Buysell', 'Job', 'To-let'];
                                    @endphp
                                    @foreach ($categories as $category)
                                        <input type="radio" class="btn-check d-none" name="category" id="cat_{{ strtolower($category) }}" value="{{ strtolower($category) }}">
                                        <label for="cat_{{ strtolower($category) }}" class="category-box text-center">
                                            {{ $category }}
                                        </label>
                                    @endforeach
                                </div>
                            </div>
                            </div>

                            <div class="form-group d-none">
                                <div class="input-group mb-2" id="AvailabilityGroup">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="bi bi-eye"></i></span>
                                    </div>
                                    <select name="availability" id="Availability" class="form-control custom-select">
                                        <option value="all_pay"
                                                data-text="{{ trans('general.desc_available_everyone_paid') }}">{{trans('general.available_everyone_paid')}}</option>
                                        <option value="free_paid_subscribers"
                                                data-text="{{ trans('general.info_price_live') }}">{{trans('general.available_free_paid_subscribers')}}</option>

                                        @if ($settings->live_streaming_free)
                                            <option value="everyone_free"
                                                    data-text="{{ trans('general.desc_everyone_free') }}">{{trans('general.available_everyone_free')}}</option>
                                        @endif
                                    </select>
                                </div>

                                @if ($settings->limit_live_streaming_paid != 0)
                                    <small class="form-text text-danger" id="LimitLiveStreamingPaid">
                                        <i class="bi bi-exclamation-triangle-fill mr-1"></i>
                                        <strong>{{ trans('general.limit__minutes_per_transmission_paid', ['min' => $settings->limit_live_streaming_paid]) }}</strong>
                                    </small>
                                @endif

                                @if ($settings->limit_live_streaming_free != 0)
                                    <small class="form-text display-none text-danger" id="everyoneFreeAlert">
                                        <i class="bi bi-exclamation-triangle-fill mr-1"></i>
                                        <strong>{{ trans('general.limit__minutes_per_transmission_free', ['min' => $settings->limit_live_streaming_free]) }}</strong>
                                    </small>
                                @endif

                            </div><!-- ./form-group -->

                            <div id="boostSection">
                            <div class="form-group mb-0">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">{{$settings->currency_symbol}}</span>
                                    </div>
                                    <input type="number" min="{{$settings->live_streaming_minimum_price}}"
                                           value="{{$settings->live_streaming_minimum_price}}"
                                           autocomplete="off" id="onlyNumber" class="form-control priceLive"
                                           name="price"
                                           placeholder="{{ __('general.budget') }}">
                                </div>
                            </div><!-- End form-group -->
                            </div>
                            <small class="form-text" style="font-size:11px"
                                   id="descAvailability">By clicking, you agree to Hubuhu's Terms & conditions.</small>


                            <div class="alert alert-danger display-none mb-0 mt-3" id="errorLive">
                                <ul class="list-unstyled m-0" id="showErrorsLive"></ul>
                            </div>

                            <div class="text-center">
                                <button type="submit" id="liveBtn" class="btn btn-primary mt-4 liveBtn">
                                    <i></i>Review Now</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- End Modal liveStreamingForm -->


<!-- Start Modal CategoryForm -->
<div class="modal fade" id="CategoryForm" tabindex="-1" role="dialog" aria-labelledby="modal-form"
    aria-hidden="true">
    <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="card bg-white shadow border-0">

                    <div class="card-body px-lg-5 py-lg-5 position-relative">

                        <div class="mb-3">
                            <i class="bi bi-broadcast mr-1"></i>
                            <strong>Review Filter</strong>
                        </div>
                        <div class="form-group mb-3" >
                            @php
                                $categoriesLoc = isset($liveStreamsCategories) ? $liveStreamsCategories : [];
                            @endphp
                            <select  id="filterLocation" name="location[]" multiple class="form-control categoriesMultiple">
                                @foreach ($categoriesLoc as $category)
                                    <option value="{{$category}}">{{$category}}</option>
                                @endforeach
                            </select>
                        </div>

                            <div class="form-group">
                                <label class="sr-only" for="category">{{ __('Category') }}</label>
                                <div class="d-flex flex-wrap justify-content-start category-grid">
                                    @php
                                        $categories = ['Buysell', 'Job', 'To-let'];
                                    @endphp
                                    @foreach ($categories as $category)
                                        <input type="radio" class="btn-check d-none" name="category" id="cat_{{ strtolower($category) }}"
                                            value="{{ strtolower($category) }}">
                                        <label for="cat_{{ strtolower($category) }}" class="category-box text-center" onclick="labelToggleClick(this)">
                                            {{ $category }}
                                        </label>
                                    @endforeach
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="button" class="btn e-none mt-4"
                                    data-dismiss="modal">{{trans('admin.cancel')}}</button>
                                <button type="submit" id="applyCategoryFilter" class="btn btn-primary mt-4">
                                    <i></i> {{trans('users.filter')}}</button>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><!-- End Modal CategoryForm -->

<style>
    .category-grid {
        max-width: 330px; /* Controls overall width of the grid */
    }

    .category-box {
        background-color: #f5f5f5;
        color: #666;
        border-radius: 10px;
        cursor: pointer;
        border: 1px solid transparent;
        width: 32%; /* Exactly 3 in one row */
        text-align: center;
        transition: all 0.2s ease-in-out;
        padding:8px;
        margin:2px;
    }

    .btn-check:checked + .category-box{
        background-color: #007bff;
        color: #fff;
        border-color: #007bff;
        font-weight: 600;
    }

    .category-box.active {
        background-color: #007bff;
        color: #fff;
        border-color: #007bff;
        font-weight: 600;
    }

    .category-box:hover {
        background-color: #e9ecef;
    }

</style>

<script>
    function labelToggleClick(element) {
        const forAttr = element.getAttribute('for');

        document.querySelectorAll('.category-box').forEach(label => {
            label.classList.remove('active');
        });

        element.classList.add('active');

        document.getElementById(forAttr).checked = true;

        console.log(`Selected category: ${document.querySelector('input[name="category"]:checked').value}`);
        console.log('Selected categories:', $('#filterLocation').val());
    }
</script>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        const tabReview = document.getElementById('tab-review');
        const tabBoost = document.getElementById('tab-boost');
        const modeInput = document.getElementById('modeInput');

        const priceInput = document.getElementById('onlyNumber');
        const submitBtn = document.getElementById('liveBtn'); // updated selector
        const boostHint = document.getElementById('boostHint');
        const boostSection = document.getElementById('boostSection');
        const categorySection = document.getElementById('categorySection');

        function updateFormState() {
            const isBoost = modeInput.value === 'boost';

            boostSection.classList.toggle('d-none', !isBoost);
            categorySection.classList.toggle('d-none', isBoost);
            submitBtn.innerHTML = isBoost ? '<i></i> Create Ad' : '<i></i> Publish';
            checkPrice();
        }

        function checkPrice() {
            if (modeInput.value === 'boost') {
                const price = parseFloat(priceInput.value);
                const isValid = !isNaN(price) && price >= 200;
                submitBtn.disabled = !isValid;
                boostHint.classList.toggle('d-none', isValid);
            } else {
                submitBtn.disabled = false;
                boostHint.classList.add('d-none');
            }
        }

        tabReview.addEventListener('click', function () {
            modeInput.value = 'review';
            tabReview.classList.add('active');
            tabBoost.classList.remove('active');
            updateFormState();
        });

        tabBoost.addEventListener('click', function () {
            modeInput.value = 'boost';
            tabBoost.classList.add('active');
            tabReview.classList.remove('active');
            updateFormState();
        });

        priceInput.addEventListener('input', checkPrice);
        updateFormState(); // Init
    });
</script>


