<!DOCTYPE html>
<html>

<head>
    <title>Verifying Payment...</title>
</head>

<body>
    <h3>Verifying your payment, please wait...</h3>

    <script>
        const urlParams = new URLSearchParams(window.location.search);
        const invoice_number = urlParams.get('invoice_number'); // or any identifier Paystation returns
        const trx_id = urlParams.get('trx_id');

        // Call your API to verify payment
        fetch(`{{ route('payment.callback') }}?invoice_number=${invoice_number}&trx_id=${trx_id}`)
            .then(async res => {
                const data = await res.json();

                if (res.ok && data.message === 'Payment successful!') {
                    window.opener.postMessage('payment_success', '*');
                } else {
                    window.opener.postMessage('payment_failed', '*');
                }

                window.close();
            }).catch(err => {
                window.opener.postMessage('payment_failed', '*');
                window.close();
            });
    </script>
</body>

</html>
