@extends('layouts.app')
<style>
    .is-invalid {
        border: 1px solid #dc3545 !important;
    }

    .img_area {
        background: #ffffff;
        border-radius: 50%;
        padding: 13px;
    }

    .ad-actions {
        position: absolute !important;
        top: 8px;
        right: 8px;
        z-index: 10;
    }

    .card.h-100 {
        position: relative; /* This ensures .ad-actions positions relative to the card */
    }

    /* Initial hidden state */
.dropdown-menu {
    display: block;
    opacity: 0;
    transform: translateY(-10px);
    transition: all 0.2s ease-in-out;
    visibility: hidden;
    pointer-events: none;
}

/* When show class is added (Bootstrap handles this) */
.dropdown-menu.show {
    opacity: 1;
    transform: translateY(0);
    visibility: visible;
    pointer-events: auto;
}


    
</style>

@section('content')
<section class="section section-sm">
    <div class="container" style="padding-top: 2rem;height:100%;">
        <div class="row" style="height: 100%;" >
            <div class="col-md-3 menu-sidebar">
                @include('includes.menu-sidebar-home')
            </div>
            <div class="col-md-9">
                <div class="row" >
                    <!-- Card 1 -->
                    <!-- Manage Ad Card with Link -->
                    <div class="col-md-4 mb-4">
                        <a href="{{ url('manage-ads') }}" class="text-decoration-none text-dark">
                            <div class="card h-100" style="background-color: #e0e0e0; min-height: 350px;">
                                <div class="card-body">
                                    <div class="d-flex flex-column justify-content-center align-items-center text-center h-100">
                                        <div class="mb-3 img_area">
                                            <img src="{{ asset('public/images/icons/megaphone.png') }}" alt="Manage Ad Icon" width="40">
                                        </div>
                                        <h5 class="card-title">Manage Ad</h5>
                                        <p class="card-text text-muted">Manage your advertise, delete, edit and more</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    

                    <div class="col-md-4 mb-4">
                        <div class="card h-100" style="background-color: #e0e0e0; min-height: 350px; cursor: pointer;" data-bs-toggle="modal" data-bs-target="#createBusinessModal">
                            <div class="card-body">
                                <div class="d-flex flex-column justify-content-center align-items-center text-center h-100">
                                    <div class="mb-3 img_area">
                                        <img src="{{ asset('public/images/icons/edit.png') }}" alt="Create Business Icon" width="40">
                                    </div>
                                    <h5 class="card-title">Create a Business</h5>
                                    <p class="card-text text-muted">Create business to promote your shop, business or products.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <span id="businessCardsStart"></span>

                </div>
            </div>                
        </div>
    </div>
</section>




<!-- Create Business Modal -->
<div class="modal fade" id="createBusinessModal" tabindex="-1" aria-labelledby="createBusinessModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content p-4 text-center" style="background-color: #f5f5f5; position: relative;">
      <!-- Modal Body -->
      <div class="modal-body">
        <div class="mb-3">
            <button type="button"
            data-bs-dismiss="modal" aria-label="Close"
                    style="position: absolute; top: 15px; right: 15px; background: transparent; border: none; font-size: 2rem; line-height: 1; color: #000;">
                &times;
            </button>
        </div>
        <form method="POST" action="{{ route('store.business.request') }}" id="submit_business_request">
            @csrf

            <div class="text-center position-relative avatar-wrap shadow mb-3" style="width: 160px; height: 160px; margin: 0 auto;">
                <!-- Upload Progress (optional) -->
                <div class="progress-upload d-none">0%</div>

                <!-- Hidden File Input -->
                <input type="file" name="business_logo" id="uploadBusinessLogo" accept="image/*" class="d-none">

                <!-- Camera Icon Button (bottom-right inside the circle) -->
                <a href="javascript:;" class="position-absolute button-avatar-upload" id="logoUploadBtn"
                style="bottom: 0; right: 0;">
                    <i class="fa fa-camera"></i>
                </a>

                <!-- Logo Image Preview -->
                <img src="{{ asset('public/images/icons/camera.png') }}" 
                    alt="Upload Logo"
                    id="businessLogoPreview"
                    class="rounded-circle"
                    style="width: 160px; height: 160px; object-fit: cover;">

                <!-- Remove Button (outside top-right corner) -->
                <button type="button" id="removeLogoBtn" class="btn btn-sm btn-danger position-absolute"
                        style="top: -10px; right: -10px; display: none; border-radius: 50%; padding: 0px 6px; z-index: 10;">&times;
                </button>

                <p class="mt-2">Upload Logo</p>
            </div>



            <!-- <div class="mb-3 position-relative d-inline-block">
                <label for="business_logo" class="d-block">
                    <div class="rounded-circle bg-secondary d-inline-block p-3" style="cursor: pointer;">
                        <img id="logo_preview" src="{{ asset('public/images/icons/camera.png') }}" alt="Upload Logo" width="30">
                    </div>
                </label>
                
                <input type="file" name="business_logo" id="business_logo" accept="image/*" style="display: none;">

                <button type="button" id="removeLogoBtn" class="btn btn-sm btn-danger position-absolute" 
                    style="top: 0px; right: 10px; display: none; border-radius:0 !important; padding: 0px 4px; z-index: 10;">&times;
                </button>

                <p class="mt-2">Upload Logo</p>
            </div> -->

        
            <div class="mb-3">
                <input type="text" class="form-control" placeholder="Business Name" name="business_name" id="business_name">
            </div>
            <div class="mb-3">
                <select  id="category_id" name="category_id" class="form-control categoriesMultiple">
                    <option value="">Category</option>
                    @foreach ($categories as $category)
                        <option value="{{$category->id }}">{{$category->name}}</option>
                    @endforeach
                </select>
               
            </div>
            <p class="small text-muted">By continue, you agreed to hubuhu business policy.</p>
            <button type="submit" class="btn btn-primary w-100 rounded-pill" style="background-color: #00BFFF;">Create Business</button>
        </form>
      </div>      
    </div>
  </div>
</div>


<!-- View Business Modal -->
<div class="modal fade" id="viewBusinessModal" tabindex="-1" aria-labelledby="viewBusinessModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content p-4 text-center" style="background-color: #f5f5f5;">
      <div class="modal-body">
        <div class="mb-3">
            <button type="button" data-bs-dismiss="modal" aria-label="Close"
                    style="position: absolute; top: 15px; right: 15px; background: transparent; border: none; font-size: 2rem; line-height: 1; color: #000;">
                &times;
            </button>
        </div>
       
        <form method="POST" id="advertise_save" class="mt-5" action="{{ route('save.advertise.request') }}">
            @csrf
            <div>
                <div id="adFirstsection">                    
                    <div class="form-group">
                        <div class="d-flex align-items-center gap-3 mb-4" style="margin-top:30px;">
                            <img id="modalBusinessLogo" src="" alt="Business Logo" width="50" height="50" class="rounded-circle border" style="margin-right:10px;">
                            <div>
                                <h5 id="modalBusinessName" class="mb-0 fw-semibold" style="font-size: 1.1rem;">Business Name</h5>
                                <small class="text-muted" id="modalBusinessCategory">Category or Tagline</small>
                            </div>
                            <input id="modalBusinessId" name="business_id" type="hidden">
                        </div>

                    </div><!-- End form-group -->                    

                    <div class="form-group mb-3 position-relative">
                        <!-- Search Input + Pin Icon -->
                        <div class="position-absolute d-flex flex-row-reverse align-items-center map_input"
                            >
                            
                            <!-- Input on the LEFT of icon -->
                            <input 
                                class="form-control"
                                type="text" name="selected_address" value="dhaka" id="autocomplete" placeholder="Search location"
                                style="border-radius: 6px;" />
                        </div>
                        <!-- Map -->
                        <div id="map" style="width: 100%; height: 300px; border-radius: 5px; overflow: hidden;"></div>
                        <!-- Radius Slider -->
                        <div id="mapRadiusControl"
                            class="map-control d-flex align-items-center shadow-sm"
                            style="position: absolute; bottom: 10px; left: 10px; z-index: 999; background: #fff; padding: 5px 10px; border-radius: 6px;">
                            <label for="radiusRange" class="radius-label me-2">
                                <span id="radiusValue">3</span> km
                            </label>
                            <input type="range" class="form-range flex-grow-1" id="radiusRange" name="address_range" min="1" max="20" value="3">
                        </div>
                    </div>
                    <div class="form-group mb-3">
                        <select id="landing_select_goal" name="select_goal" class="form-control categoriesMultiple">
                            <option value="">Select Goal</option>
                            <option value="send_message">&#128172; Send message</option>
                            <option value="visit_now">&#127970; Visit now</option>
                            <option value="buy_now">&#128179; Buy now</option>
                            <option value="order_now">&#128717; Order now</option>
                            <option value="start_now">&#128640; Start now</option>
                            <option value="install_now">&#128187; Install now</option>
                            <option value="learn_more">&#128214; Learn more</option>
                            <option value="chat_on_whatsapp">&#128241; Chat on WhatsApp</option>
                        </select>
                        <!-- Shown only when WhatsApp option is selected -->
                        <div id="whatsappInputContainer" class="form-group d-none">
                            <div class="input-group">
                                <select class="form-select" style="max-width: 120px;" name="country_code" id="country_code">
                                    <option value="+91">+91</option>
                                    <option value="+880">+880</option>
                                    <option value="+1">+1</option>
                                    <option value="+92">+92</option>                                                
                                </select>
                                <input type="text" class="form-control" id="whatsapp_number" name="whatsapp_number" placeholder="Enter WhatsApp Number">
                            </div>
                        </div>
                        <div id="sendMessageInputContainer" class="form-group d-none">
                            <input type="text" class="form-control" id="send_message" name="send_message" placeholder="Send Message">
                        </div>
                        <div id="visitNowInputContainer" class="form-group d-none">
                            <input type="text" class="form-control" id="visit_now" name="visit_now" placeholder="Enter Url">
                        </div>
                        <div id="buyNowInputContainer" class="form-group d-none">
                            <input type="text" class="form-control" id="buy_now" name="buy_now" placeholder="Enter Url">
                        </div>
                        <div id="orderNowInputContainer" class="form-group d-none">
                            <input type="text" class="form-control" id="order_now" name="order_now" placeholder="Enter Url">
                        </div>
                        <div id="startNowInputContainer" class="form-group d-none">
                            <input type="text" class="form-control" id="start_now" name="start_now" placeholder="Enter Url">
                        </div>
                        <div id="installNowInputContainer" class="form-group d-none">
                            <input type="text" class="form-control" id="install_now" name="install_now" placeholder="Enter Url">
                        </div>
                        <div id="learnMoreInputContainer" class="form-group d-none">
                            <input type="text" class="form-control" id="learn_more" name="learn_more" placeholder="Enter Url">
                        </div>
                    </div>
                </div>
                <div id="adSecondsection" class="d-none">
                        <div class="form-group mb-3">
                        <textarea id="goal_description" name="goal_description" class="form-control" rows="3" placeholder="Ad Description" required></textarea>
                        <div class="invalid-feedback" id="errorGoalDesc"></div>
                    </div>
                    <!-- Upload Preview Box -->
                    <div class="form-group mb-3">
                        <div class="position-relative">
                            <div id="uploadPreviewBox" class="d-flex align-items-center justify-content-center">
                                <span class="text-muted text-center">Upload Ad<br><small>Ad will preview here</small></span>
                            </div>
                            <button type="button" id="removeMediaBtn" class="btn btn-sm  position-absolute" 
                                style="top: 10px; right: 10px; display: none; z-index: 10;">X</button>
                            <input type="file" id="mediaUpload" name="ad_media" accept="image/*,video/*" class="form-control mt-2" required>
                            <div class="invalid-feedback d-block" id="errorMediaUpload"></div>
                        </div>                                        
                    </div>
                    <div class="form-group mb-0">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">{{$settings->currency_symbol}}</span>
                            </div>
                            <input type="number" min="{{$settings->live_streaming_minimum_price}}"
                                value="{{$settings->live_streaming_minimum_price}}"
                                autocomplete="off" id="adPrice" class="form-control priceLive"
                                name="price" required
                                placeholder="{{ __('general.budget') }}">
                                <div class="invalid-feedback" id="errorPrice"></div>
                        </div>
                    </div><!-- End form-group -->
                    
                </div>
                
            </div>
            <small class="form-text mb-3" style="font-size:11px"
                    id="descAvailability">By clicking, you agree to Hubuhu's Terms & conditions.</small>

            <div class="alert alert-danger display-none mb-0 mt-3" id="errorLive">
                <ul class="list-unstyled m-0" id="showErrorsLive"></ul>
            </div>
            <div class="text-center justify-content-center gap-3 mt-3">
                <button type="button" id="adnextStepBtn" class="btn btn-primary">Next</button>
                <button type="button" id="adbackStepBtn" class="btn btn-outline-secondary mt-4">Back</button>
                <button id="createAdBtn" class="btn btn-primary mt-4 d-none" type="button">
                    <span class="spinner-border spinner-border-sm me-2 d-none" role="status" aria-hidden="true" id="createAdSpinner"></span>
                    <span id="createAdBtnText">Create Ad</span>
                </button>


            </div>             
        </form>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>


@endsection
@section('javascript')

<script>
    $(document).on('click', '[data-toggle="dropdown"]', function (e) {
    var $dropdown = $(this).next('.dropdown-menu');

    $('.dropdown-menu').not($dropdown).removeClass('show'); // Close others
    $dropdown.toggleClass('show');
    e.preventDefault();
    e.stopPropagation();
});

$(document).on('click', function () {
    $('.dropdown-menu').removeClass('show'); // Close all when clicking elsewhere
});

$(document).on('click', '[data-toggle="dropdown"]', function (e) {
    var $dropdown = $(this).next('.dropdown-menu');

    $('.dropdown-menu').not($dropdown).removeClass('show'); // Close others
    $dropdown.toggleClass('show');
    e.preventDefault();
    e.stopPropagation();
});

$(document).on('click', function () {
    $('.dropdown-menu').removeClass('show'); // Close all when clicking elsewhere
});


document.addEventListener("DOMContentLoaded", function () {
    const nextBtn = document.getElementById("adnextStepBtn");
    const backBtn = document.getElementById("adbackStepBtn");
    const createAdBtn = document.getElementById("createAdBtn");
    const step1 = document.getElementById("adFirstsection");
    const step2 = document.getElementById("adSecondsection");

    // Required fields
    const selectedAddress = document.getElementById("autocomplete");
    const goalSelect = document.getElementById("landing_select_goal");
    const whatsappInput = document.getElementById("whatsapp_number");
    const whatsappContainer = document.getElementById("whatsappInputContainer");
    const visitNowInput = document.getElementById("visit_now");
    const buyNowInput = document.getElementById("buy_now");
    const orderNowInput = document.getElementById("order_now");
    const startNowInput = document.getElementById("start_now");
    const installNowInput = document.getElementById("install_now");
    const learnMoreInput = document.getElementById("learn_more");
    const sendMessageInput = document.getElementById("send_message");

    // Hide second step & buttons initially
    step2.classList.add("d-none");
    backBtn.classList.add("d-none");

    function showError(input, message = "This field is required") {
        input.classList.add("is-invalid");
        input.focus();
    }

    function clearErrors() {
        const invalidFields = document.querySelectorAll(".is-invalid");
        invalidFields.forEach(el => el.classList.remove("is-invalid"));
    }

    function validateStep1() {
        clearErrors();

        if (selectedAddress.value.trim() === "") {
            showError(selectedAddress);
            return false;
        }

        if (goalSelect.value === "") {
            showError(goalSelect);
            return false;
        }

        // Conditional input based on goal selection
        switch (goalSelect.value) {
            case "chat_on_whatsapp":
                if (whatsappInput.value.trim() === "") {
                    showError(whatsappInput);
                    return false;
                }
                break;
            case "visit_now":
                if (visitNowInput.value.trim() === "") {
                    showError(visitNowInput);
                    return false;
                }
                break;
            case "buy_now":
                if (buyNowInput.value.trim() === "") {
                    showError(buyNowInput);
                    return false;
                }
                break;
            case "order_now":
                if (orderNowInput.value.trim() === "") {
                    showError(orderNowInput);
                    return false;
                }
                break;
            case "start_now":
                if (startNowInput.value.trim() === "") {
                    showError(startNowInput);
                    return false;
                }
                break;
            case "install_now":
                if (installNowInput.value.trim() === "") {
                    showError(installNowInput);
                    return false;
                }
                break;
            case "learn_more":
                if (learnMoreInput.value.trim() === "") {
                    showError(learnMoreInput);
                    return false;
                }
                break;
            case "send_message":
                if (sendMessageInput.value.trim() === "") {
                    showError(sendMessageInput);
                    return false;
                }
                break;
        }

        return true;
    }

    nextBtn.addEventListener("click", function () {
        if (validateStep1()) {
            step1.classList.add("d-none");
            step2.classList.remove("d-none");
            nextBtn.classList.add("d-none");
            createAdBtn.classList.remove("d-none");
            backBtn.classList.remove("d-none");
        }
    });

    backBtn.addEventListener("click", function () {
        step1.classList.remove("d-none");
        step2.classList.add("d-none");
        nextBtn.classList.remove("d-none");
        createAdBtn.classList.add("d-none");
        backBtn.classList.add("d-none");
        clearErrors();
    });

    // Goal selection toggle inputs
    goalSelect.addEventListener("change", function () {
        const containers = {
            chat_on_whatsapp: whatsappContainer,
            visit_now: visitNowInput.parentElement,
            buy_now: buyNowInput.parentElement,
            order_now: orderNowInput.parentElement,
            start_now: startNowInput.parentElement,
            install_now: installNowInput.parentElement,
            learn_more: learnMoreInput.parentElement,
            send_message: sendMessageInput.parentElement
        };

        Object.values(containers).forEach(container => container.classList.add("d-none"));

        if (containers[goalSelect.value]) {
            containers[goalSelect.value].classList.remove("d-none");
        }
    });
});
</script>


<script>
    $(document).ready(function () {
        var csrfToken = $('meta[name="csrf-token"]').attr('content');
        getBusinessList();
        // Reset validation state
        function resetValidation() {
            $('#business_name').removeClass('is-invalid');
            $('#category_id').removeClass('is-invalid');
        }

        // Open file selector when camera icon is clicked
$('#logoUploadBtn').on('click', function () {
    $('#uploadBusinessLogo').click();
});

// On image file selected
$('#uploadBusinessLogo').on('change', function () {
    const file = this.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function (e) {
            $('#businessLogoPreview')
                .attr('src', e.target.result)
                .css({ width: '160px', height: '160px', 'object-fit': 'cover' });
            $('#removeLogoBtn').show();
        };
        reader.readAsDataURL(file);
    }
});

// Remove uploaded image and reset to default
$('#removeLogoBtn').on('click', function () {
    $('#uploadBusinessLogo').val('');
    $('#businessLogoPreview')
        .attr('src', '{{ asset('public/images/icons/camera.png') }}')
        .css({ width: '160px', height: '160px', 'object-fit': 'cover' });
    $(this).hide();
});




        $('#submit_business_request').on('submit', function (e) {
            e.preventDefault();
            resetValidation();
            let isValid = true;
            let businessName = $('#business_name').val().trim();
            let categoryId = $('#category_id').val();

            if (businessName === "") {
                $('#business_name').addClass('is-invalid').focus();
                isValid = false;
            }

            if (categoryId === "") {
                $('#category_id').addClass('is-invalid');
                if (isValid) $('#category_id').focus(); // focus only first invalid
                isValid = false;
            }

            if (!isValid) return;

            const formData = new FormData(this);
            $.ajax({
                url: "{{ route('store.business.request') }}",
                method: "POST",
                data: formData,
                processData: false,
                contentType: false,
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                },
                data: formData,
                success: function (response) {
                    getBusinessList();
                    // Success feedback
                    alert('Business created successfully!');
                    $('#createBusinessModal').modal('hide');
                    $('#submit_business_request')[0].reset();
                },
                error: function (xhr) {
                    // Handle errors
                    let errMsg = 'Something went wrong!';
                    if (xhr.responseJSON && xhr.responseJSON.message) {
                        errMsg = xhr.responseJSON.message;
                    }
                    alert(errMsg);
                }
            });
        });
    });

    
    function getBusinessList() {
    $.ajax({
        url: "{{ route('fetch.businesses') }}",
        method: "GET",
        success: function (response) {
            // Remove old business cards first
            $('.dynamic-business-card').remove();

            response.businesses.forEach(function (business) {
                const card = `
                    <div class="col-md-4 mb-4 dynamic-business-card">
                        <div class="card h-100 position-relative" style="background-color: #e0e0e0; min-height: 350px;" >
                            
                            <!-- Three-dot icon at top-right -->
                            <!-- Cross icon button to directly delete the business -->
<button type="button"
        class="text-white bg-secondary rounded-circle d-flex align-items-center justify-content-center border-0"
        onclick="deleteBusiness(${business.id})"
        style="width: 30px; height: 30px; position: absolute; top: 10px; right: 10px; cursor: pointer;">
    <i class="bi bi-x" style="font-size: 16px;"></i>
</button>

                    
                            <div class="card-body" onclick="viewBusiness('${business.id}','${business.logo_url}', '${business.name}')">
                                <div class="d-flex flex-column justify-content-center align-items-center text-center h-100">
                                    <div class="position-relative mb-3 img_area">
                                        <img src="${business.logo_url}" alt="Business Logo" width="40">
                                    </div>
                                    <h5 class="card-title">${business.name}</h5>
                                    <p class="card-text text-muted">${business.category_name}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                `;

                // Append after the "Create Business" card marker
                $('#businessCardsStart').after(card);
            });
        }
    });
}

function deleteBusiness(id){
    if (!confirm("Delete this ad permanently?")) return;
    fetch(`/app/business/delete/${id}`, {
        method: 'POST',
        headers: {
            'X-CSRF-TOKEN': '{{ csrf_token() }}',
            'Accept': 'application/json'
        }
    })
    .then(response => {
        if (!response.ok) throw new Error("Failed to delete ad");
        return response.json();
    })
    .then(data => {
        alert(data.message);
        location.reload(); // Or remove the card from DOM
    })
    .catch(error => {
        console.error(error);
        alert('Something went wrong.');
    });
}

function viewBusiness(id,logoUrl, name, category) {
    $('#modalBusinessId').val(id);
    $('#modalBusinessLogo').attr('src', logoUrl);
    $('#modalBusinessName').text(name);
    $('#viewBusinessModal').modal('show');
}


</script>
@endsection