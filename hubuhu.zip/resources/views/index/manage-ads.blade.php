@extends('layouts.app')

@section('content')
<style>
    .ad-image-wrapper {
        position: relative;
    }

    .card-text {
        font-size: 16px;
        margin-top: 5px;
        margin-bottom: 5px;
        font-weight: 600;
    }

    .description-header {
        font-size: 15px;
        font-weight: 600;
        margin-bottom: 2px;
    }
    .description-text {
        font-size: 13px;
        font-weight: 500;
    }

    .ad-actions {
        padding: 4px;
        border-radius: 5px;
        position: absolute;
        top: 8px;
        right: 8px;
        display: flex;
        gap: 8px;
        transition: opacity 0.3s ease;
    }

    .card-body {
    padding: 0.9rem !important;
}
    .ad-actions i {
        font-size: 1.5rem;
        cursor: pointer;
    }

    .description-block {
    min-width: 0;
    word-wrap: break-word;
}

    .ad-image-wrapper:hover .ad-actions {
        opacity: 1;
    }

    .card-body {
        padding: 12px 10px;
    }

    .card-footer {
        padding: 10px;
    }

    .ad-card {
        margin-bottom: 15px;
    }

    .row.gx-1 > [class*="col-"] {
        padding-left: 5px;
        padding-right: 5px;
    }
    .ad-card .add_image img {
        height: 200px;
        object-fit:cover;
    }

    video::-webkit-media-controls-enclosure {
        overflow: hidden;
    }

    video::-webkit-media-controls-panel {
        background-color: transparent !important;
    }

    video::-webkit-media-controls-timeline {
        background: transparent !important;
    }

    video::-webkit-media-controls-current-time-display,
    video::-webkit-media-controls-time-remaining-display {
        color: white; /* or your preferred color */
    }


</style>
<section class="section section-sm pb-0 mb-4" style="height: 100%;">
    <div class="container container-lg-3 pt-lg-5 pt-2" style="padding-top: 2rem;height:100%;">
        <div class="row" style="height: 100%;">
            <div class="col-md-3 menu-sidebar">
                @include('includes.menu-sidebar-home')
            </div>
            <div class="col-md-9">
                <div class="row  gx-1">
                    @forelse($ads as $ad)
                        <div class="col-md-4 mb-3">
                            
                            <div class="ad-card card shadow-sm">
                                <div class="position-relative add_image">
                                    @php
                                        $mediaPath = $ad->ad_media ?? $ad->ad_file; // Fallback to ad_file if ad_media is missing
                                        $extension = strtolower(pathinfo($mediaPath, PATHINFO_EXTENSION));
                                        $isImage = in_array($extension, ['jpg', 'jpeg', 'png', 'webp', 'gif']);
                                        $isVideo = in_array($extension, ['mp4', 'webm', 'ogg']);
                                    @endphp
                                    @if ($isImage)
                                        <img src="{{ asset('public/storage/'.$ad->ad_file) }}" class="card-img-top" alt="Ad Image">
                                    @elseif ($isVideo)
                                        <video class="card-img-top rounded-3"  muted playsinline preload="metadata" style="height: 194px; width: 100%; object-fit: cover;">
                                            <source src="{{ asset('public/storage/'.$mediaPath) }}" type="video/{{ $extension }}">
                                            Your browser does not support the video tag.
                                        </video>
                                    @endif
                                    
                                    <div class="ad-actions d-flex gap-2" style="position: absolute; top: 10px; left: 10px;">
                                        @if($ad->ad_status == "active")
                                            <span class="badge badge-success d-flex align-items-center" style="height:30px; padding: 8px;border-radius: 100px;">Active</span>
                                        @else
                                            <span class="badge badge-secondary d-flex align-items-center" style="height:30px; padding: 8px;border-radius: 100px;">Pause</span>
                                        @endif
                                    </div>



                                    <div class="ad-actions d-flex gap-2" style="position: absolute; top: 10px; right: 10px;">
                                        @if($ad->ad_status == "active")
                                            <!-- Pause Icon -->
                                            <button type="button"
                                                    onclick="pauseAd({{ $ad->id }})"
                                                    class="bg-secondary text-white rounded-circle border-0 d-flex align-items-center justify-content-center"
                                                    style="width: 30px; height: 30px; cursor: pointer;">
                                                <i class="bi bi-pause-fill" style="font-size: 16px;"></i>
                                            </button>
                                        @else
                                            <!-- Resume Icon -->
                                            <button type="button"
                                                    onclick="reactiveAd({{ $ad->id }})"
                                                    class="bg-secondary text-white rounded-circle border-0 d-flex align-items-center justify-content-center"
                                                    style="width: 30px; height: 30px; cursor: pointer;">
                                                <i class="bi bi-play-fill" style="font-size: 16px;"></i>
                                            </button>
                                        @endif

                                        <!-- Delete (Cross) Icon -->
                                        <button type="button"
                                                onclick="deleteAd({{ $ad->id }})"
                                                class="bg-secondary text-white rounded-circle border-0 d-flex align-items-center justify-content-center"
                                                style="width: 30px; height: 30px; cursor: pointer;">
                                            <i class="bi bi-x" style="font-size: 16px;"></i>
                                        </button>
                                    </div>
                                    <!-- Show description above the media -->
                                
                                     <div class="position-absolute w-100 px-2 py-1 text-white text-center"
                                         style="bottom: 0; left: 0; background: rgba(0, 0, 0, 0.6); font-size: 14px;">
                                        {{ \Illuminate\Support\Str::limit($ad->goal_description, 30) }}
                                    </div>
                              
                                   
                                </div>
                                <div class="card-body text-center">
                                    
                                    <div class="row">
                                        <div class="col-5 border-right text-center"> <!-- mobile & up -->
                                            <div class="description-block">
                                                <h5 class="description-header ">{{ $settings->currency_symbol }}0.78/1000</h5>
                                                <span class="description-text">Spent</span>
                                            </div>
                                        </div>
                                        <div class="col-3 border-right text-center">
                                            <div class="description-block">
                                                <h5 class="description-header">{{ number_format($ad->impressions) }}</h5>
                                                <span class="description-text">Reach</span>
                                            </div>
                                        </div>
                                        <div class="col-4 text-center">
                                            <div class="description-block">
                                                <h5 class="description-header">{{ number_format($ad->clicks) }}</h5>
                                                <span class="description-text">Total Clicks</span>
                                            </div>
                                        </div>
                                    </div>

                                    
                                </div>
                                <!-- <div class="card-footer text-center">
                                    <div class="row">
                                        <div class="col-sm-12 border-right">
                                            <div class="description-block">
                                                <span class="description-text font-weight-normal">Budget Spent</span>
                                                <h5 class="description-header">0.78/1000</h5>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    @empty
                        <div class="col-12">
                            <div class="card text-center p-4 shadow-sm">
                                <h5 class="mb-0 text-muted">No ads found.</h5>
                            </div>
                        </div>
                    @endforelse
                </div>
            </div>                
        </div>
    </div>
</section>


<script>
    

     function pauseAd(adId) {
        swal(
        {
            title: "Pause Ad Confirmation",
            text: "Are you sure you want to pause this Ad?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "Cancel",
            closeOnConfirm: false,
            closeOnCancel: true
        },
        function (isConfirm) {
            if (isConfirm) {
                fetch(`/ads/${adId}/pause`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) throw new Error("Failed to pause ad");
                    return response.json();
                })
                .then(data => {
                    swal({
                        title: "Success!",
                        text: data.message || "Business has been deleted successfully.",
                        type: "success"
                    }, function() {
                        location.reload();
                    });
                    
                })
                .catch(error => {
                    console.error(error);
                    alert('Something went wrong.');
                });
            }
        })
    }

    function reactiveAd(adId) {
        swal(
        {
            title: "Active Ad Confirmation",
            text: "Are you sure you want to active this Ad?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "Cancel",
            closeOnConfirm: false,
            closeOnCancel: true
        },
        function (isConfirm) {
            if (isConfirm) {
                fetch(`/ads/${adId}/reactive`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) throw new Error("Failed to pause ad");
                    return response.json();
                })
                .then(data => {
                    swal({
                        title: "Success!",
                        text: data.message || "Business has been deleted successfully.",
                        type: "success"
                    }, function() {
                        location.reload();
                    });
                    
                })
                .catch(error => {
                    console.error(error);
                    alert('Something went wrong.');
                });
            }
        })
    }

     


    function deleteAd(adId) {
    swal(
        {
            title: "Delete Ad Confirmation",
            text: "Are you sure you want to delete this Ad?",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "Yes",
            cancelButtonText: "Cancel",
            closeOnConfirm: false,
            closeOnCancel: true
        },
        function (isConfirm) {
            if (isConfirm) {
                fetch(`/ads/${adId}`, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json'
                    }
                })
                .then(response => {
                    if (!response.ok) throw new Error("Failed to delete");
                    return response.json();
                })
                .then(data => {
                    swal({
                        title: "Deleted!",
                        text: data.message || "Business has been deleted successfully.",
                        type: "success"
                    }, function() {
                        location.reload();
                    });
                })
                .catch(error => {
                    console.error(error);
                    swal({
                        title: "Error!",
                        text: "Something went wrong while deleting.",
                        type: "error"
                    });
                });
            }
        }
    );
}
</script>


@endsection


