@extends('layouts.app')

@section('css')
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
@endsection
<style>



.ad-card {
    position: relative;
    width: 100%;
    max-width: 450px;
    height: auto;
    overflow: hidden;
    display: none;
}

/* Main Ad Image (clear one, in center) */
.ad-main-image {
    width: 100%;
    margin-top: 60px;
    height: 350px !important;
    max-height: 40vh; /* Makes image height responsive to viewport */
    object-fit: fill; /* Keeps aspect ratio without cropping */
    z-index: 2;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.4);
}


.ad-main-video {
    width: 100%;
    margin-top: 60px;
    height: 350px !important;
    max-height: 40vh; /* Makes image height responsive to viewport */
    object-fit: fill; /* Keeps aspect ratio without cropping */
    z-index: 2;
}
.ad-card.active {
    display: block !important;
}

.ad-background-image {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    z-index: 1;
    filter: blur(15px);
}

.ad-content-wrapper {
    position: relative;
    z-index: 2;
}

.dot.bg-light {
    background-color: #fff !important;
}

.dot.bg-secondary {
    background-color: #6c757d !important;
}


.goal_data {
    border-radius: 20px;
    padding: 15px 0px;
    margin: 0px 20px;
    background: rgba(255, 255, 255, 0.1); /* Slight white transparency */
    backdrop-filter: blur(10px); /* Main blur effect */
    -webkit-backdrop-filter: blur(10px); /* Safari support */
    border: 1px solid rgba(255, 255, 255, 0.2); /* Optional border for visibility */
    color: white; /* Ensures text is visible on blur */
}
.goal_data-overlay {
    position: absolute;
    bottom: 60px; /* ❌ You missed the "px" unit here */
    left: 0;
    right: 0;
    padding: 15px 0;
    margin: 0 10px 10px 10px;
    background: rgba(0, 0, 0, 0.4);
    backdrop-filter: blur(3px);
    -webkit-backdrop-filter: blur(10px);
    z-index: 999;
    border-radius: 10px;
}


.logo-spacing {
    margin-right: 10px; /* adjust as needed */
}
.exclamation-btn {
    width: 38px;
    height: 38px;
    background-color: rgba(0, 0, 0, 0.6) !important; /* or solid: #333 */
    border: none;
    color: white !important;
    box-shadow: 0 0 2px rgba(0,0,0,0.6);
    font-size: 18px;
    transition: background-color 0.3s;
}

.exclamation-btn:hover {
    background-color: rgba(0, 0, 0, 0.8);
}

.custom-icon-size {
    font-size: 24px; /* or 28px, 32px, etc. */
}




/* Responsive adjustments for smaller devices */
@media (max-width: 768px) {
    .ad-main-image {
        max-height: 50vh;
        margin-top: 15px;
    }

    .ad-main-video {
        max-height: 50vh;
        margin-top: 15px;
    }
}

@media (max-width: 576px) {
    .ad-main-image {
        max-height: 39vh;
        margin-top: 0px;
    }

    .ad-main-video {
        max-height: 39vh;
        margin-top: 0px;
    }

    .goal_data-overlay {
        margin: 0 8px;
        padding: 10px 8px;
    }
}

 .full-description::-webkit-scrollbar {
        display: none;
    }

/*.ad-slide.active.with-border {
  border-top: 5px solid #f0c000; 
}
  */
</style>


@section('content')
    <section class="section section-sm pb-0" style="height: 100%;">
        <div class="container container-lg-3 pt-lg-5 pt-2" style="padding-top: 2rem;height:100%;">
            <div class="row" style="height: 100%;">
                <div class="col-md-3 menu-sidebar">
                    @include('includes.menu-sidebar-home')
                </div>
                <div class="col-md-6 p-0 second wrap-post" style="background-color: transparent">
                    @if ($stories->count() || ($settings->story_status && auth()->user()->verified_id == 'yes'))
                        <div id="stories" class="storiesWrapper mb-2 p-2">
                            @if ($settings->story_status && auth()->user()->verified_id == 'yes')
                                <div class="add-story" title="{{ __('general.add_story') }}">
                                    <a class="item-add-story" href="#" data-toggle="modal" data-target="#addStory">
                                        <span class="add-story-preview">
                                            <img lazy="eager" width="100" src="{{ Helper::getFile(config('path.avatar') . auth()->user()->avatar) }}">
                                        </span>
                                        <span class="info py-3 text-center text-white bg-primary">
                                            <strong class="name" style="text-shadow: none;">
                                                <i class="bi-plus-circle-dotted mr-1"></i>
                                                {{ __('general.add_story') }}
                                            </strong>
                                        </span>
                                    </a>
                                </div>
                            @endif
                        </div>
                    @endif

                    @if (
                        ($settings->announcement != '' &&
                            $settings->announcement_show == 'creators' &&
                            auth()->user()->verified_id == 'yes') ||
                            ($settings->announcement != '' && $settings->announcement_show == 'all'))
                        <div class="alert alert-{{ $settings->type_announcement }} announcements display-none card-border-0"
                            role="alert">
                            <button type="button" class="close" id="closeAnnouncements">
                                <span aria-hidden="true">
                                    <i class="bi bi-x-lg"></i>
                                </span>
                            </button>

                            <h4 class="alert-heading"><i class="bi bi-megaphone mr-2"></i> {{ __('general.announcements') }}
                            </h4>
                            <p class="update-text">
                                {!! $settings->announcement !!}
                            </p>
                        </div><!-- end announcements -->
                    @endif

                    @if ($payPerViewsUser != 0)
                        <div class="col-md-12 d-none">
                            <ul class="list-inline">
                                <li class="list-inline-item text-uppercase h5">
                                    <a href="{{ url('/') }}"
                                        class="text-decoration-none @if (request()->is('/')) link-border @else text-muted @endif">{{ __('admin.home') }}</a>
                                </li>
                                <li class="list-inline-item text-uppercase h5">
                                    <a href="{{ url('my/purchases') }}"
                                        class="text-decoration-none @if (request()->is('my/purchases')) link-border @else text-muted @endif">{{ __('general.purchased') }}</a>
                                </li>
                            </ul>
                        </div>
                    @endif

                    <div class="d-none">
                        @if (auth()->user()->verified_id == 'yes')
                            @include('includes.modal-add-story')

                            @include('includes.form-post')
                        @endif
                    </div>

    @if ($ads->count() != 0)
    <div class="d-flex justify-content-center" >
        <div class="position-relative w-100" style="max-width: 450px;">
            <div id="adSliderContainer">
                @php $index = 0; @endphp
                @foreach ($ads as $ad)
                    <div class="ad-card ad-slide d-none flex-column justify-content-between text-white" data-index="{{ $index }}">
                        <!-- Background image -->
                        <img src="{{ asset('public/storage/'.$ad->ad_file) }}" alt="Ad Image" class="ad-background-image">
                        <!-- Content wrapper -->
                        @php
                                    $mediaPath = $ad->ad_media ?? $ad->ad_file; // Fallback to ad_file if ad_media is missing
                                    $extension = strtolower(pathinfo($mediaPath, PATHINFO_EXTENSION));
                                    $isImage = in_array($extension, ['jpg', 'jpeg', 'png', 'webp', 'gif']);
                                    $isVideo = in_array($extension, ['mp4', 'webm', 'ogg']);
                                @endphp
                        <div class="ad-content-wrapper d-flex flex-column justify-content-between h-100 {{ $isVideo ? 'bg-black' : '' }}">
                            <!-- Top Bar -->
                            <div class="d-flex justify-content-between align-items-center mb-2 px-3 pt-3">
                            <div class="d-flex align-items-center">
                                <img src="{{ $ad->business && $ad->business->logo ? asset('/public/storage/'.$ad->business->logo) : asset('default.jpg') }}"
                                     class="rounded-circle me-2"
                                     width="40" height="40"
                                     alt="Logo"
                                     style="margin-right:4px; background: white;">
                                <div>
                                    <strong class="d-block">{{ $ad->business->business_name ?? 'Sponsored' }}</strong>
                                    <small class="text-muted">Sponsored</small>
                                </div>
                            </div>
                            
                            <!-- Play/Pause Button -->
                            <div class="d-flex align-items-center gap-2">
                                @if ($isVideo)                                   

                                    <button class="btn btn-light rounded-circle d-flex   align-items-center justify-content-center toggle-play-btn"
                                            data-target="video-{{ $ad->id }}"
                                            style="width: 40px; height: 40px; margin-right: 8px;">
                                        <i class="bi bi-pause-fill"></i>
                                    </button>
                                @endif
                                <!-- Report Button -->
                                <button class="btn exclamation-btn rounded-circle d-flex align-items-center justify-content-center" data-toggle="modal" data-target="#reportCreator-{{ $ad->id }}">
                                    <i class="bi bi-exclamation custom-icon-size"></i>
                                </button>
                            </div>
                        </div>
                            <!-- Center Ad Image -->
                            <div class="d-flex flex-column flex-grow-1">
                                
                                @if ($isImage)
                                    <img src="{{ asset('public/storage/'.$mediaPath) }}" alt="Ad Image" class="ad-main-image img-fluid rounded-3">
                                @elseif ($isVideo)
                                    <div class="flex-grow-1 pb-3">
                                        <video id="video-{{ $ad->id }}"
                                            class="ad-main-video rounded-3"
                                            loop
                                            playsinline
                                            preload="metadata"
                                            >
                                            <source src="{{ asset('public/storage/'.$mediaPath) }}" type="video/{{ $extension }}">
                                            Your browser does not support the video tag.
                                        </video>
                                    </div>
                                @endif

                            </div>


                            <!-- CTA Overlay -->
                            <div class="goal_data-overlay text-center text-white mx-3" >
                                <!-- Description Wrapper -->
                                <div class="description-wrapper text-white">
                                    <!-- Arrow for showing full description -->
                                    <div class="toggle-control text-center" onclick="toggleDescription(this)" style="cursor: pointer;">
                                        <i class="arrow-icon fas fa-chevron-up"></i>
                                    </div>

                                    <!-- Short Description -->
                                    <p class="mb-1 fw-semibold short-description text-center" onclick="toggleDescription(this)" style="font-size: 0.95rem;">
                                        {{ \Illuminate\Support\Str::words($ad->goal_description, 10, '...') }}
                                    </p>

                                    <!-- Full Description -->
                                    <div class="full-description d-none fw-semibold" 
                                        style="font-size: 0.95rem; max-height: 150px; overflow-y: auto; margin:15px !important; text-align: left; scrollbar-width: none; -ms-overflow-style: none;" onclick="toggleDescription(this)">
                                        {{ $ad->goal_description }}

                                        <!-- Arrow to collapse full description -->
                                        
                                    </div>
                                </div>

                                @php
                                $goals = [
                                    'visit_now' => $ad->visit_now,
                                    'chat_on_whatsapp' => $ad->visit_now, // Note: Seems like this might be a mistake, maybe it should be `$ad->chat_on_whatsapp`?
                                    'send_message' => $ad->send_message,
                                    'buy_now' => $ad->buy_now,
                                    'order_now' => $ad->order_now,
                                    'start_now' => $ad->start_now,
                                    'install_now' => $ad->install_now,
                                ];

                                $link = $goals[$ad->goal] ?? $ad->learn_more;
                            @endphp

                            <a href="{{ $link ?? '#' }}" target="_blank" class="btn btn-primary btn-sm w-75 rounded-pill">
                                {{ \Illuminate\Support\Str::title(str_replace('_', ' ', $ad->goal)) }}
                            </a>

                            </div>

                            <!-- Bottom Buttons -->
                            <div class="d-flex justify-content-center align-items-center mb-3">
                                <button class="btn btn-secondary rounded-circle d-flex align-items-center justify-content-center prevAd mx-2" style="width: 40px; height: 38px;">
                                    <i class="bi bi-chevron-left"></i>
                                </button>

                                <button class="btn btn-secondary rounded-pill px-4 skipAd mx-2 d-flex justify-content-center align-items-center" style="height: 38px;">
                                    Skip
                                </button>

                                <button class="btn btn-secondary rounded-circle d-flex align-items-center justify-content-center mx-2" style="width: 40px; height: 38px;">
                                    <i class="bi bi-list"></i>
                                </button>
                            </div>
                        </div>
                    </div> 


                    <div class="modal fade modalReport" id="reportCreator-{{ $ad->id }}" tabindex="-1" role="dialog" aria-hidden="true">
                        <div class="modal-dialog modal-danger modal-sm">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h6 class="modal-title font-weight-light">
                                        <i class="fas fa-flag mr-1"></i> {{ __('general.report_user') }}
                                    </h6>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <i class="fa fa-times"></i>
                                    </button>
                                </div>

                                <form method="POST" action="{{ url('report/creator/' . $ad->user_id) }}" enctype="multipart/form-data">
                                    @csrf
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label>{{ __('admin.please_reason') }}</label>
                                            <select name="reason" class="form-control custom-select">
                                                <option value="spoofing">{{ __('admin.spoofing') }}</option>
                                                <option value="copyright">{{ __('admin.copyright') }}</option>
                                                <option value="privacy_issue">{{ __('admin.privacy_issue') }}</option>
                                                <option value="violent_sexual">{{ __('admin.violent_sexual_content') }}</option>
                                                <option value="spam">{{ __('general.spam') }}</option>
                                                <option value="fraud">{{ __('general.fraud') }}</option>
                                                <option value="under_age">{{ __('general.under_age') }}</option>
                                            </select>
                                            <textarea name="message" class="form-control mt-2 textareaAutoSize" maxlength="200" placeholder="{{ __('general.message') }} ({{ __('general.optional') }})"></textarea>
                                        </div>
                                    </div>

                                    <div class="modal-footer">
                                        <button type="button" class="btn border text-white" data-dismiss="modal">{{ __('admin.cancel') }}</button>
                                        <button type="submit" class="btn btn-xs btn-white sendReport ml-auto">
                                            {{ __('general.report_user') }}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                @php $index++; @endphp
                @endforeach  
                <div class="menuMobile w-100 bg-white shadow-lg p-3 border-top">
                    <ul class="list-inline d-flex bd-highlight m-0 text-center">

                <li class="flex-fill bd-highlight">
                    <a class="p-3 btn-mobile" href="{{url('/')}}" title="{{trans('admin.home')}}">
                        <i class="feather icon-home icon-navbar"></i>
                    </a>
                </li>

                @if (!$settings->disable_creators_section)
                <li class="flex-fill bd-highlight">
                    <a class="p-3 btn-mobile" href="{{url('creators')}}" title="{{trans('general.explore')}}">
                        <i class="far   fa-compass icon-navbar"></i>
                    </a>
                </li>
                @endif

            @if ($settings->shop)
                <li class="flex-fill bd-highlight">
                    <a class="p-3 btn-mobile" href="{{url('shop')}}" title="{{trans('general.shop')}}">
                        <i class="feather icon-shopping-bag icon-navbar"></i>
                    </a>
                </li>
            @endif

            <li class="flex-fill bd-highlight">
                <a href="{{url('messages')}}" class="p-3 btn-mobile position-relative" title="{{ trans('general.messages') }}">

                    <span class="noti_msg notify @if (auth()->user()->messagesInbox() != 0) d-block @endif">
                        {{ auth()->user()->messagesInbox() }}
                        </span>

                    <i class="feather icon-send icon-navbar"></i>
                </a>
            </li>

            <li class="flex-fill bd-highlight">
                <a href="{{url('notifications')}}" class="p-3 btn-mobile position-relative" title="{{ trans('general.notifications') }}">
                    <span class="noti_notifications notify @if (auth()->user()->unseenNotifications()) d-block @endif">
                        {{ auth()->user()->unseenNotifications() }}
                        </span>
                    <i class="far fa-bell icon-navbar"></i>
                </a>
            </li>
            </ul>
</div>                    
            </div>     
        </div>
    </div>

                    @else
                        <div class="stream--container">
                            <div class="grid-updates position-relative" id="updatesPaginator"></div>
                            <div id="remote-streams" style="position:relative;"></div>
                            <div class="" id="no-stream-msg">
                                <i class="bi bi-camera-video-off-fill"></i>No ad found
                            </div>
                        </div>
                    @endif


                </div><!-- end col-md-12 -->

                <div class="col-md-3 @if ($users->count() != 0) mb-4 @endif d-lg-block d-none">
                    <div class="d-lg-block sticky-top">
                        @if ($users->count() == 0)
                            <div class="panel panel-default panel-transparent mb-4 d-lg-block d-none">
                                <div class="panel-body">
                                    <div class="media none-overflow">
                                        <div class="d-flex my-2 align-items-center">
                                            <img class="rounded-circle mr-2" src="{{ Helper::getFile(config('path.avatar') . auth()->user()->avatar) }}" width="60" height="60">
                                            <div class="d-block">
                                                <strong>{{ auth()->user()->name }}</strong>

                                                <div class="d-block">
                                                    <small class="media-heading text-muted btn-block margin-zero">
                                                        <a href="{{ url('settings/page') }}">
                                                            {{ auth()->user()->verified_id == 'yes' ? __('general.edit_my_page') : __('users.edit_profile') }}
                                                            <small class="pl-1"><i class="fa fa-long-arrow-alt-right"></i></small>
                                                        </a>
                                                    </small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endif

                        @if ($users->count() != 0)
                            @include('includes.explore_creators')
                        @endif

                        <div class="d-lg-block d-none">
                            @include('includes.footer-tiny')
                        </div>
                    </div><!-- sticky-top -->

                </div><!-- col-md -->
            </div>
        </div>
    </section>




    <div id="next-prev-container" style="display:none;">
        <div class="container container-lg-3 px-0 floating_btn" style="">
            <div class="button-container">
                <div class="circle-btn" id="prevButton">
                    <i class="bi bi-chevron-left"></i>
                </div>
                <button class="btn btn-primary main-btn" id="nextButton" style="">SKIP</button>
                <div class="circle-btn" id="cartegoryButton">
                    <i class="bi bi-filter"></i>
                </div>
            </div>
        </div>
    </div>
@endsection
<script>
document.addEventListener('DOMContentLoaded', function (e) {
    e.preventDefault();
    document.querySelectorAll('.toggle-play-btn').forEach(button => {
        button.addEventListener('click', function () {
            const videoId = this.getAttribute('data-target');
            const video = document.getElementById(videoId);
            const icon = this.querySelector('i');

            if (video) {
                if (video.paused) {
                    video.play();
                    icon.classList.remove('bi-play-fill');
                    icon.classList.add('bi-pause-fill');
                } else {
                    video.pause();
                    icon.classList.remove('bi-pause-fill');
                    icon.classList.add('bi-play-fill');
                }
            }
        });
    });
});
</script>


<script>
    
    function toggleDescription(el) {
    const wrapper = el.closest('.description-wrapper');
    const shortDesc = wrapper.querySelector('.short-description');
    const fullDesc = wrapper.querySelector('.full-description');
    const allArrows = wrapper.querySelectorAll('.arrow-icon');

    const isShortVisible = !shortDesc.classList.contains('d-none');

    if (isShortVisible) {
        // Showing full description
        shortDesc.classList.add('d-none');
        fullDesc.classList.remove('d-none');
        allArrows.forEach(icon => {
            icon.classList.remove('fa-chevron-up');   // 👈 reverse logic
            icon.classList.add('fa-chevron-down');
        });
    } else {
        // Showing short description
        shortDesc.classList.remove('d-none');
        fullDesc.classList.add('d-none');
        allArrows.forEach(icon => {
            icon.classList.remove('fa-chevron-down'); // 👈 reverse logic
            icon.classList.add('fa-chevron-up');
        });
    }
}

</script>
<script>
document.addEventListener("DOMContentLoaded", function () {
    const slides = document.querySelectorAll(".ad-slide");
    const dotContainers = document.querySelectorAll("#dotContainer .dot");
    const nextBtns = document.querySelectorAll(".nextAd");
    const prevBtns = document.querySelectorAll(".prevAd");
    const skipBtns = document.querySelectorAll(".skipAd");

    let currentIndex = 0;
    let borderTimeout;
    let skipCountdown;
    let userHasInteracted = false;
    function showSlide(index) {
        console.log(index);
        console.log("sad")
        slides.forEach((slide) => {
            slide.classList.remove("active", "with-border");
        });

        const activeSlide = slides[index];
        activeSlide.classList.add("active", "with-border");
        handleSkipButton(activeSlide);

        // If the active slide has a video, unmute and play
        const video = activeSlide.querySelector("video");
        if (video) {
            video.muted = false;
            video.currentTime = 0; // start from beginning if needed
            video.play().catch(err => {
                console.warn("Autoplay failed:", err);
            });
        }
    }

    // Detect first user interaction
    // function enableAudioPlaybackOnce() {
    //     if (!userHasInteracted) {
    //         userHasInteracted = true;
    //         const video = slides[currentIndex].querySelector("video");
    //         if (video) {
    //             video.pause();
    //             video.muted = false;
    //             video.play();
    //         }
    //     }
    //     document.removeEventListener("click", enableAudioPlaybackOnce);
    // }
    // document.addEventListener("click", enableAudioPlaybackOnce);


    
    // Show first slide
    showSlide(currentIndex);

    function goToNextSlide() {
        const currentSlide = slides[currentIndex];

        // Pause current video (if any)
        const currentVideo = currentSlide.querySelector("video");
        if (currentVideo) {
            currentVideo.pause();
        }

        // Update index
        const next = (currentIndex + 1) % slides.length;
        currentIndex = next;

        // Show next slide
        showSlide(next);
    }


    function goToPrevSlide() {
        const currentSlide = slides[currentIndex];

        // Pause current video (if any)
        const currentVideo = currentSlide.querySelector("video");
        if (currentVideo) {
            currentVideo.pause();
        }

        // Update index
        const prev = (currentIndex - 1 + slides.length) % slides.length;
        currentIndex = prev;

        // Show previous slide
        showSlide(prev);
    }


    // Bind all buttons in all slides
    nextBtns.forEach(btn => btn.addEventListener("click", goToNextSlide));
    prevBtns.forEach(btn => btn.addEventListener("click", goToPrevSlide));
    skipBtns.forEach(btn => btn.addEventListener("click", goToNextSlide));

    function handleSkipButton(activeSlide) {
    const skipBtn = activeSlide.querySelector(".skipAd");
    if (!skipBtn) return;

    skipBtn.disabled = true;

    let countdown = 5;
    skipBtn.textContent = countdown + " Sec"; // Show with 'sec'

    clearInterval(skipCountdown);
    skipCountdown = setInterval(() => {
        countdown--;
        if (countdown > 0) {
            skipBtn.textContent = countdown + " Sec";
        } else {
            clearInterval(skipCountdown);
            skipBtn.disabled = false;
            skipBtn.textContent = "Skip";
        }
    }, 1000);
}


    
});
</script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('video').forEach(video => {
        let startTime = 0;

        video.addEventListener('play', () => {
            startTime = Date.now();
        });

        video.addEventListener('pause', () => {
            if (!startTime) return;

            const watchedSeconds = Math.round((Date.now() - startTime) / 1000);
            const adId = video.dataset.adId;
            var track_view_url="{{ route('store.track.view.request') }}";
            if (adId && watchedSeconds > 0) {
                fetch(track_view_url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    },
                    body: JSON.stringify({
                        ad_id: adId,
                        watched_seconds: watchedSeconds
                    })
                })
                .then(res => res.json())
                .then(data => {
                    console.log(`Earned: ${data.earned} | Creator got: ${data.creator_received} | Admin cut: ${data.admin_commission}`);
                });
            }

            startTime = 0; // reset
        });
    });
});
</script>

@section('javascript')
    @if (session('noty_error'))
        <script type="text/javascript">
            swal({
                title: "{{ __('general.error_oops') }}",
                text: "{{ __('general.already_sent_report') }}",
                type: "error",
                confirmButtonText: "{{ __('users.ok') }}"
            });
        </script>
    @endif

    @if (session('noty_success'))
        <script type="text/javascript">
            swal({
                title: "{{ __('general.thanks') }}",
                text: "{{ __('general.reported_success') }}",
                type: "success",
                confirmButtonText: "{{ __('users.ok') }}"
            });
        </script>
    @endif

    @if (session('success_verify'))
        <script type="text/javascript">
            swal({
                title: "{{ __('general.welcome') }}",
                text: "{{ __('users.account_validated') }}",
                type: "success",
                confirmButtonText: "{{ __('users.ok') }}"
            });
        </script>
    @endif

    @if (session('error_verify'))
        <script type="text/javascript">
            swal({
                title: "{{ __('general.error_oops') }}",
                text: "{{ __('users.code_not_valid') }}",
                type: "error",
                confirmButtonText: "{{ __('users.ok') }}"
            });
        </script>
    @endif

    @if ($settings->story_status && $stories->count())
        <script>
            let stories = new Zuck('stories', {
                skin: 'snapssenger', // container class
                avatars: false, // shows user photo instead of last story item preview
                list: false, // displays a timeline instead of carousel
                openEffect: true, // enables effect when opening story
                cubeEffect: false, // enables the 3d cube effect when sliding story
                autoFullScreen: false, // enables fullscreen on mobile browsers
                backButton: true, // adds a back button to close the story viewer
                backNative: false, // uses window history to enable back button on browsers/android
                previousTap: true, // use 1/3 of the screen to navigate to previous item when tap the story
                localStorage: true, // set true to save "seen" position. Element must have a id to save properly.

                stories: [

                    @foreach ($stories as $story)
                        {
                            id: "{{ $story->user->username }}", // story id
                            photo: "{{ Helper::getFile(config('path.avatar') . $story->user->avatar) }}", // story photo (or user photo)
                            name: "{{ $story->user->hide_name == 'yes' ? $story->user->username : $story->user->name }}", // story name (or user name)
                            link: "{{ url($story->user->username) }}", // story link (useless on story generated by script)
                            lastUpdated: {{ $story->created_at->timestamp }}, // last updated date in unix time format

                            items: [
                                // story item example

                                @foreach ($story->media as $media)
                                    {
                                        id: "{{ $story->user->username }}-{{ $story->id }}", // item id
                                        type: "{{ $media->type }}", // photo or video
                                        length: {{ $media->type == 'photo' ? 5 : ($media->video_length ?: $settings->story_max_videos_length) }}, // photo timeout or video length in seconds - uses 3 seconds timeout for images if not set
                                        src: "{{ Helper::getFile(config('path.stories') . $media->name) }}", // photo or video src
                                        preview: "{{ $media->type == 'photo' ? route('resize', ['path' => 'stories', 'file' => $media->name, 'size' => 280]) : ($media->video_poster ? route('resize', ['path' => 'stories', 'file' => $media->video_poster, 'size' => 280]) : route('resize', ['path' => 'avatar', 'file' => $story->user->avatar, 'size' => 200])) }}", // optional - item thumbnail to show in the story carousel instead of the story defined image
                                        link: "", // a link to click on story
                                        linkText: '{{ $story->title }}', // link text
                                        time: {{ $media->created_at->timestamp }}, // optional a date to display with the story item. unix timestamp are converted to "time ago" format
                                        seen: false, // set true if current user was read
                                        story: "{{ $media->id }}",
                                        text: "{{ $media->text }}",
                                        color: "{{ $media->font_color }}",
                                        font: "{{ $media->font }}",
                                    },
                                @endforeach
                            ]
                        },
                    @endforeach

                ],

                callbacks: {
                    onView(storyId) {
                        getItemStoryId(storyId);
                    },

                    onEnd(storyId, callback) {
                        getItemStoryId(storyId);
                        callback(); // on end story
                    },

                    onClose(storyId, callback) {
                        getItemStoryId(storyId);
                        callback(); // on close story viewer
                    },

                    onNavigateItem(storyId, nextStoryId, callback) {
                        getItemStoryId(storyId);
                        callback(); // on navigate item of story
                    },
                },

                language: { // if you need to translate :)
                    unmute: '{{ __('general.touch_unmute') }}',
                    keyboardTip: 'Press space to see next',
                    visitLink: 'Visit link',
                    time: {
                        ago: '{{ __('general.ago') }}',
                        hour: '{{ __('general.hour') }}',
                        hours: '{{ __('general.hours') }}',
                        minute: '{{ __('general.minute') }}',
                        minutes: '{{ __('general.minutes') }}',
                        fromnow: '{{ __('general.fromnow') }}',
                        seconds: '{{ __('general.seconds') }}',
                        yesterday: '{{ __('general.yesterday') }}',
                        tomorrow: 'tomorrow',
                        days: 'days'
                    }
                }
            });

            function getItemStoryId(storyId) {
                let userActive = '{{ auth()->user()->username }}';
                if (userActive !== storyId) {
                    let itemId = $('#zuck-modal .story-viewer[data-story-id="' + storyId + '"]').find('.itemStory.active').data(
                        'id-story');
                    insertViewStory(itemId);
                }
                insertTextStory();
            }

            insertTextStory();

            function insertTextStory() {
                $('.previewText').each(function() {
                    let text = $(this).find('.items>li:first-child>a').data('text');
                    let font = $(this).find('.items>li:first-child>a').data('font');
                    let color = $(this).find('.items>li:first-child>a').data('color');
                    $(this).find('.text-story-preview').css({
                        fontFamily: font,
                        color: color
                    }).html(text);
                });
            }

            function insertViewStory(itemId) {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.post(URL_BASE + "/story/views/" + itemId + "");
            }

            $(document).on('click', '.profilePhoto, .info>.name', function() {
                let element = $(this);
                let username = element.parents('.story-viewer').data('story-id');
                if (username) {
                    window.location.href = URL_BASE + '/' + username;
                }
            });
        </script>
    @endif


    <script src="{{ asset('public/js/agora/AgoraRTCSDK-v4.js') }}"></script>

    <script>
        let filterCategory = '';
        let filterLocations = [];
        const blurDuration = 60000; // 60 seconds
        let currentVideoIndex = 0;
        const videoElements = [];
        const remoteUsers = {};
        let filteredStreams = [];
        let currentAgoraClient = null;

        document.getElementById('applyCategoryFilter').addEventListener('click', function() {
            const selectedCategory = document.querySelector('input[name="category"]:checked');
            const locationInput = document.getElementById('filterLocation');
            let upon= false;

            if (locationInput) {
                const selectedOptions = Array.from(locationInput.selectedOptions);
                filterLocations = selectedOptions.map(option => option.value);
                if (filterLocations.length > 0) {
                    upon = true;
                }
            }

            if (selectedCategory) {
                console.log('Selected Locations:', filterLocations);
                console.log('Selected Category:', filterCategory);
                upon = true;
                filterCategory = selectedCategory.value;

            }

            if(upon){
                $('#CategoryForm').modal('hide');
                loadLiveStream()
            }
        });

        async function renderLiveStream(live) {
            const appId = '{{ $settings->agora_app_id }}';
            const token = null;
            const uid = null;
            const remoteStreams = document.getElementById("remote-streams");
            remoteStreams.style.height = "100%";
            const channel = `live_${live.user_id}`;

            const payedLive = @json($payedLive);

            const individualClient = AgoraRTC.createClient({
                mode: "live",
                codec: "vp8"
            });
            currentAgoraClient = individualClient;
            individualClient.setClientRole("audience");

            individualClient.join('{{ $settings->agora_app_id }}', channel, null, null).then(() => {
                individualClient.on("user-published", async (user, mediaType) => {
                    await individualClient.subscribe(user, mediaType);

                    // if(user.audioTrack.isplaying){
                    //     user.audioTrack.stop();
                    // }

                    if (mediaType === "video") {
                        const remoteVideo = document.createElement("div");
                        remoteVideo.classList.add("remote-video-container");
                        remoteVideo.id = `user-${user.uid}-channel-${channel}`;
                        remoteVideo.setAttribute("data-info", JSON.stringify(live))
                        remoteStreams.appendChild(remoteVideo);

                        const videoElement = document.createElement("video");
                        videoElement.autoplay = true;
                        videoElement.playsInline = true;
                        videoElement.classList.add("remote-video");
                        remoteVideo.appendChild(videoElement);
                        user.videoTrack.play(videoElement);

                        // Handle blur timing
                        const blurKey = `blurred_${channel}_${user.uid}`;
                        const isPayedLive = Array.isArray(payedLive) && payedLive.length > 0 ?
                            payedLive.some(paidLive => paidLive && paidLive.live_streamings_id === live
                                .live_id) :
                            false;

                        applyCanvasBlurEffect(videoElement, remoteVideo, live, isPayedLive, blurKey);

                        createVideoOverlay(remoteVideo, live, isPayedLive);
                    }

                    remoteUsers[`user-${user.uid}-channel-${channel}`] = user;

                    if (mediaType === "audio") {
                        user.audioTrack.play();
                    }
                });

                individualClient.on("user-unpublished", (user) => {
                    const remoteVideo = document.getElementById(`user-${user.uid}-channel-${channel}`);
                    if (remoteVideo) remoteVideo.remove();
                });
            }).catch((err) => {
                console.error(`Failed to join channel ${channel}:`, err);
            });
        }

        async function loadLiveStream() {
            @php
                $defaultLocation1 = isset($defaultLocation) ? $defaultLocation : []; // or ->locations or ->city etc.
            @endphp
            const liveStreams = @json($liveStreams);
            const defLocation = @json($defaultLocation1);


            let filteredStreams = liveStreams;
            let pass = false;

            filteredStreams = liveStreams.filter(stream => {
                let categoryMatch = true;
                let locationMatch = true;
                let locationMatchDef = true;


                if (filterCategory) {
                    categoryMatch = stream.category === filterCategory;
                    pass = true;
                }

                if (Array.isArray(filterLocations) && filterLocations.length > 0) {
                    pass = true;
                    const creatorAllowedLocations = Array.isArray(stream.locations)
                        ? stream.locations
                        : (typeof stream.locations === 'string' && stream.locations.trim().startsWith('[')
                            ? JSON.parse(stream.locations) : []); // fallback if JSON string

                    locationMatch = filterLocations.some(loc => {
                        const normalizedLoc = loc.toLowerCase();

                        // match against creator's allowed locations
                        const matchCreatorAllowed = creatorAllowedLocations.some(allowed =>
                            allowed.toLowerCase() === normalizedLoc || allowed.toLowerCase().includes(normalizedLoc)
                        );

                        return matchCreatorAllowed;
                    });
                }else if(Array.isArray(defLocation) && defLocation.length > 0){
                    pass = true;
                    const creatorAllowedLocations = Array.isArray(stream.locations)
                        ? stream.locations
                        : (typeof stream.locations === 'string' && stream.locations.trim().startsWith('[')
                            ? JSON.parse(stream.locations) : []); // fallback if JSON string

                    locationMatchDef = defLocation.some(loc => {
                        const normalizedLoc = loc.toLowerCase();

                        // match against creator's allowed locations
                        const matchCreatorAllowedDef = creatorAllowedLocations.some(allowed =>
                            allowed.toLowerCase() === normalizedLoc || allowed.toLowerCase().includes(normalizedLoc)
                        );

                        return matchCreatorAllowedDef;
                    });
                }

                return categoryMatch && locationMatch && locationMatchDef;
            });

            if(!pass){
                filteredStreams = {};
            }

            const remoteStreams = document.getElementById("remote-streams");
            while (remoteStreams.firstChild) {
                remoteStreams.removeChild(remoteStreams.firstChild);
            }
            // Leave and destroy the previous client if it exists
            if (currentAgoraClient != null) {
                console.log("current")
                try {
                    // Stop all remote users' tracks
                    Object.values(remoteUsers).forEach(user => {
                        if (user.videoTrack) {
                            user.videoTrack.stop();
                            user.videoTrack.close && user.videoTrack.close();
                        }
                        if (user.audioTrack) {
                            user.audioTrack.stop();
                            user.audioTrack.close && user.audioTrack.close();
                        }
                    });
                    // Clear remoteUsers object
                    for (const key in remoteUsers) {
                        delete remoteUsers[key];
                    }

                    // Remove all video containers from DOM
                    const remoteStreams = document.getElementById("remote-streams");
                    while (remoteStreams.firstChild) {
                        remoteStreams.removeChild(remoteStreams.firstChild);
                    }

                    await currentAgoraClient.leave();
                    currentAgoraClient.removeAllListeners();
                    currentAgoraClient = null;
                } catch (err) {
                    console.error("Error leaving previous Agora client:", err);
                }
            }


            if (Array.isArray(filteredStreams) && filteredStreams.length > 0) {
                const noStreamMsg = document.getElementById("no-stream-msg");
                if (noStreamMsg) noStreamMsg.style.display = "none";

                if (filteredStreams.length > 0) {
                    currentVideoIndex = 0;
                    renderLiveStream(filteredStreams[currentVideoIndex]);
                }
                

            } else {
                const noStreamMsg = document.getElementById("no-stream-msg");
                if (noStreamMsg) noStreamMsg.style.display = "flex";
                remoteStreams.style.height = "auto";
            }
        }

        function applyCanvasBlurEffect(videoElement, container, live, isPayedLive, blurKey) {
            if (!isPayedLive) {
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d");
                const blurAmount = isPayedLive ? 0 : 10;
                let isBlurred = localStorage.getItem(blurKey) === 'true';

                canvas.width = container.offsetWidth;
                canvas.height = container.offsetHeight;
                container.appendChild(canvas);
                blurButtonShown = false

                let lastRenderTime = 0;
                const frameRate = 15;

                function renderFrame() {
                    const now = performance.now();
                    if (now - lastRenderTime < 1000 / frameRate) {
                        requestAnimationFrame(renderFrame);
                        return;
                    }
                    lastRenderTime = now;

                    isBlurred = localStorage.getItem(blurKey)

                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

                    console.log(blurDuration)
                    if (isBlurred) {
                        ctx.filter = `blur(${blurAmount}px)`;
                        ctx.filter = blur(`${blurAmount}px`);
                        ctx.drawImage(canvas, 0, 0);
                        if (!isPayedLive) {
                            if (!blurButtonShown) {
                                showBlurAndButton(videoElement, live.username, live.id, live.live_name, blurKey, live
                                    .live_id, isPayedLive);
                                blurButtonShown = true;
                            }
                        }
                    }

                    videoElement.style.display = "none";
                    requestAnimationFrame(renderFrame);
                }
                renderFrame();

                setTimeout(() => {
                    isBlurred = true;
                    localStorage.setItem(blurKey, 'true');
                    renderFrame();
                    // showBlurAndButton(videoElement,live.name)
                }, blurDuration);
            } else {
                showBlurAndButton(videoElement, live.username, live.id, live.live_name, blurKey, live.live_id, isPayedLive);
            }
        }

        function createVideoOverlay(container, live, isPayedLive) {
            const overlay = document.createElement("div");
            overlay.classList.add("video-overlay");

            const header = document.createElement("div");
            header.classList.add("overlay-header");

            // Left section (profile and text)
            const leftSection = document.createElement("div");
            leftSection.style.display = "flex";
            leftSection.style.alignItems = "center";
            leftSection.style.gap = "10px";
            if (!isPayedLive) {
                leftSection.style.visibility = "hidden"
            }

            // Profile Circle
            const profileCircle = document.createElement("div");
            profileCircle.style.width = "32px";
            profileCircle.style.height = "32px";
            profileCircle.style.borderRadius = "50%";
            profileCircle.style.border = "2px solid red";
            profileCircle.style.background =
                "white url('/path/to/profile-placeholder.png') center/cover no-repeat"; // Replace with actual path
            leftSection.appendChild(profileCircle);

            // Name and time
            const nameTimeContainer = document.createElement("div");
            const name = document.createElement("div");
            name.innerText = live.username;
            name.style.fontWeight = "bold";
            const time = document.createElement("div");
            time.innerText = "Started 1 minute ago";
            time.style.fontSize = "12px";
            time.style.opacity = "0.8";
            nameTimeContainer.appendChild(name);
            nameTimeContainer.appendChild(time);
            leftSection.appendChild(nameTimeContainer);

            // Live badge
            const liveBadge = document.createElement("div");
            liveBadge.innerText = "LIVE";
            liveBadge.style.background = "#E50914";
            liveBadge.style.padding = "4px 8px";
            liveBadge.style.borderRadius = "4px";
            liveBadge.style.fontWeight = "bold";
            liveBadge.style.marginLeft = "10px";

            // Right section (icons)
            const rightSection = document.createElement("div");
            rightSection.style.display = "flex";
            rightSection.style.alignItems = "center";
            rightSection.style.gap = "16px";
            if (!isPayedLive) {
                rightSection.style.display = "none"
            }

            const eyeIcon = document.createElement("span");
            eyeIcon.innerHTML = `<i class="fa fa-eye"></i> 0`;
            eyeIcon.style.display = "none"
            rightSection.appendChild(liveBadge);
            rightSection.appendChild(eyeIcon);

            const micIcon = document.createElement("span");
            micIcon.innerHTML = `<i class="bi bi-volume-up-fill"></i>`;
            micIcon.id = "micIcon"
            rightSection.appendChild(micIcon);

            const moreIcon = document.createElement("span");
            moreIcon.innerHTML = `<i class="bi bi-three-dots"></i>`;
            moreIcon.id = "moreIcon";
            rightSection.appendChild(moreIcon)

            header.appendChild(leftSection)
            header.appendChild(rightSection)

            const commmentOverlay = document.createElement("div");
            commmentOverlay.id = "commentOverlay";
            commmentOverlay.classList.add("comment-overlay")
            const bottomOverlay = document.createElement("div");
            bottomOverlay.style.width = "100%";
            bottomOverlay.style.position = "absolute";
            bottomOverlay.style.bottom = "0";
            bottomOverlay.classList.add("bottomOverlay");
            bottomOverlay.appendChild(commmentOverlay)

            const viewrsField = document.createElement("div");
            viewrsField.classList.add("viewers-field");
            const inputField = document.createElement("input");
            inputField.classList.add("comment-input");
            inputField.placeholder = "Write something...";
            inputField.disabled = !isPayedLive;

            overlay.appendChild(header);
            viewrsField.appendChild(inputField);
            const tipButton = document.createElement("button");
            tipButton.type = "button";
            tipButton.className = "btn btn-tooltip e-none align-bottom buttons-live";
            tipButton.style.padding = "0";
            tipButton.style.height = "auto"
            tipButton.id = "tipButton";
            tipButton.setAttribute("data-toggle", "modal");
            tipButton.setAttribute("data-target", "#tipForm");
            tipButton.title = "{{ __('general.tip') }}";
            tipButton.innerHTML = `
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor" class="bi bi-coin" viewBox="0 0 16 16">
                    <path d="M5.5 9.511c.076.954.83 1.697 2.182 1.785V12h.6v-.709c1.4-.098 2.218-.846 2.218-1.932 0-.987-.626-1.496-1.745-1.76l-.473-.112V5.57c.6.068.982.396 1.074.85h1.052c-.076-.919-.864-1.638-2.126-1.716V4h-.6v.719c-1.195.117-2.01.836-2.01 1.853 0 .9.606 1.472 1.613 1.707l.397.098v2.034c-.615-.093-1.022-.43-1.114-.9H5.5zm2.177-2.166c-.59-.137-.91-.416-.91-.836 0-.47.345-.822.915-.925v1.76h-.005zm.692 1.193c.717.166 1.048.435 1.048.91 0 .542-.412.914-1.135.982V8.518l.087.02z"></path>
                    <path fill-rule="evenodd" d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
                    <path fill-rule="evenodd" d="M8 13.5a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zm0 .5A6 6 0 1 0 8 2a6 6 0 0 0 0 12z"></path>
                </svg>
            `;
            tipButton.disabled = !isPayedLive;
            viewrsField.appendChild(tipButton);
            const sendLiveChatButton = document.createElement("span");
            sendLiveChatButton.className = "btn-primary btn icons-live e-none align-bottom buttons-live";
            sendLiveChatButton.id = "sendLiveChat";
            sendLiveChatButton.innerHTML = `<i class="bi bi-chevron-right"></i>`;
            sendLiveChatButton.disabled = !isPayedLive;
            viewrsField.appendChild(sendLiveChatButton);
            if (isPayedLive) {
                viewrsField.classList.add("d-flex")
                $('.floating_btn').hide()
                overlay.style.display = "flex"
                document.querySelector(".section-sm").style.setProperty("padding-bottom", "0px", "important");
                shouldHideMenuMobile = true;
                document.querySelector(".floating_btn").style.bottom = "0.4rem";
            } else {
                viewrsField.style.display = "none";
                overlay.style.display = "none";
            }
            bottomOverlay.appendChild(viewrsField);
            overlay.appendChild(bottomOverlay)

            container.appendChild(overlay);
        }

        // Styles
        const style = document.createElement("style");
        style.innerHTML = `
            .remote-video-container { position: relative; width: 100%; height: calc(100vh - 170px); }
            .remote-video { width: 100%; height: 100%; object-fit: cover; }
            .video-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; flex-direction: column; justify-content: space-between; }
            .overlay-header { display: flex; align-items:center; justify-content: space-between; padding: 10px 20px; background-color: transparent; margin-top: 10px; color: white; }
            .viewers-field: {height: auto; align-items: center; justify-content: space-between; gap: 8px; margin-bottom:10px; padding:0 15px; }
            .live-label { background-color: red; padding: 5px; color: #fff; border-radius: 5px; }
            .comment-input { width: 95%; padding: 8px; border: 1px solid #ccc; border-radius: 18px; background: transparent; color:white;}
            .buttons-live {color: #fff; }
            .comment-overlay {max-height: 40%; overflow-y: auto; display: flex; flex-direction: column; font-family: sans-serif; color: white; font-size: 14px; padding: 0 10px; margin-bottom:10px;}
        `;
        document.head.appendChild(style);

        function showBlurAndButton(videoElement, link, linkId, liveName, blurKey, live_id, isPayedLive) {
            //
            const anchorDiv = document.createElement("div");
            anchorDiv.style.width = "100%"
            anchorDiv.style.height = "100px"
            anchorDiv.style.display = "flex"
            anchorDiv.style.justifyContent = "center"
            anchorDiv.style.alignItems = "center"
            anchorDiv.style.zIndex = "500"
            anchorDiv.classList = "blurDiv"

            const liveNameSpan = document.createElement("span")
            liveNameSpan.innerHTML = liveName
            liveNameSpan.style.color = "#fff"
            liveNameSpan.style.fontSize = "20px"
            liveNameSpan.style.marginBottom = "2px"

            const anchorDivDiv = document.createElement("div")
            anchorDivDiv.style.background = "rgba(47, 47, 47, 0.41)"
            anchorDivDiv.style.width = "85%"
            anchorDivDiv.style.height = "90px"
            anchorDivDiv.style.borderRadius = "16px"
            anchorDivDiv.style.boxShadow = "0 4px 30px rgba(0, 0, 0, 0.1)"
            anchorDivDiv.style.backdropFilter = "blur(7.9px)"
            anchorDivDiv.style.webkitBackdropFilter = "blur(7.9px)"
            anchorDivDiv.style.display = "flex"
            anchorDivDiv.style.justifyContent = "end"
            anchorDivDiv.style.alignItems = "center"
            anchorDivDiv.style.flexDirection = "column"
            anchorDivDiv.style.paddingBottom = "5px"

            const anchor = document.createElement("a");
            anchor.classList.add("btn", "btn-primary");
            if (isPayedLive) {
                console.log('ewds')
                liveData = getCurrentStreamData()
                anchor.id = "routeLive";
                anchor.innerHTML = "View";
                anchor.href = `/live/${liveData.username}`;
                videoElement.style.filter = "blur(8px)";
            } else {
                anchor.innerHTML = "Play";
                anchor.href = `/live/${link}?_id=${linkId}`;
                anchor.id = "playButton";
            }
            anchor.setAttribute("data-id", live_id);
            anchor.setAttribute("data-key", blurKey);

            videoElement.parentNode.appendChild(anchorDiv);
            anchorDivDiv.appendChild(liveNameSpan)
            anchorDivDiv.appendChild(anchor)
            anchorDiv.appendChild(anchorDivDiv)
            // anchorDiv.appendChild(videoElement);
            // buttonContainer.appendChild(anchorDiv);


            anchorDiv.style.position = "absolute";
            anchorDiv.style.bottom = "10rem";
            // anchorDiv.style.left = "";
            // anchor.style.border = "none";
            // anchor.style.backgroundColor = "#000";
            anchor.style.padding = "10px 120px";
            anchor.style.fontSize = "16px";
            anchor.style.textDecoration = "none";
            anchor.style.color = "#fff";
        }

        $(document).on("click", "#playButton", function(e) {
            liveData = getCurrentStreamData()
            e.preventDefault();
            const id = e.target.dataset.id;
            const paymentGateway = $('input[name="payment_gateway_live"]:checked').val();

            $.ajax({
                url: "{{ url('send/payment/live') }}",
                type: "POST",
                data: {
                    _token: "{{ csrf_token() }}",
                    id: id,
                    payment_gateway_live: paymentGateway
                },
                success: function(response) {
                    if (response.success) {
                        console.log("Payment successful");
                        localStorage.setItem(e.target.dataset.key, "no-blur")
                        const url = new URL(window.location.href);
                        window.location.href = `/live/${liveData.username}`

                    } else {
                        console.error("Payment failed:", response.errors);
                        // Display errors if any
                        if (response.errors) {
                            let errorHtml = '';
                            for (let key in response.errors) {
                                errorHtml += `<li>${response.errors[key]}</li>`;
                            }
                            document.querySelector('.error-message').innerHTML = errorHtml;
                            document.querySelector('.modal-overlay').style.display =
                                'flex'; // Assuming you have an error container
                        }
                    }
                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", error);
                    swal({
                        title: "Error",
                        text: "An error occurred while processing the payment.",
                        type: "error",
                        confirmButtonText: "OK"
                    });
                }
            });
        })

        function displayComment(username, message, id, isVerified = true) {
            const commentBox = document.getElementById("commentOverlay");

            // Create the main comment contain
            const msg = document.createElement("div");
            msg.id = "comment-wrap"
            msg.setAttribute("data-id", id);
            msg.style.display = "flex";
            msg.style.alignItems = "center";
            msg.style.marginBottom = "10px";

            // Profile image
            const profileImage = document.createElement("div");
            profileImage.style.width = "30px";
            profileImage.style.height = "30px";
            profileImage.style.borderRadius = "50%";
            profileImage.style.background = "white url('/path/to/profile-placeholder.png') center/cover no-repeat";
            profileImage.style.marginRight = "10px";

            // Comment content container
            const content = document.createElement("div");
            content.style.display = "flex";
            // content.style.flexDirection = "column";

            // Username and verified badge
            const usernameContainer = document.createElement("div");
            usernameContainer.style.display = "flex";
            usernameContainer.style.alignItems = "center";

            const usernameText = document.createElement("strong");
            usernameText.innerText = username;
            usernameText.style.color = "white";
            usernameText.style.marginRight = "5px";

            usernameContainer.appendChild(usernameText);

            if (isVerified) {
                const verifiedBadge = document.createElement("small");
                verifiedBadge.className = "verified";
                verifiedBadge.innerHTML = `<i class="bi bi-patch-check-fill" style="color: #0d6efd;"></i>`;
                usernameContainer.appendChild(verifiedBadge);
            }

            // Message text
            const messageText = document.createElement("div");
            messageText.innerText = message;
            messageText.style.color = "white";
            messageText.style.fontSize = "14px";
            messageText.style.marginLeft = "5px";

            // Append username and message to content
            content.appendChild(usernameContainer);
            content.appendChild(messageText);

            // Append profile image and content to the main container
            msg.appendChild(profileImage);
            msg.appendChild(content);

            commentBox.appendChild(msg);
            commentBox.scrollTop = commentBox.scrollHeight;
        }

        function showPaymentErrorToast(message) {
            const toastElement = document.getElementById('paymentErrorModal');
            const toastMessage = document.getElementById('paymentErrorMessage');

            toastMessage.innerHTML = message;
            $(toastElement).fadeIn();
            setTimeout(() => {
                $(toastElement).fadeOut();
            }, 5000);
        }

        const mutedUsers = {}; // Track mute state per user

        $(document).on('click', '#micIcon', function(e) {
            e.preventDefault();

            const $icon = $(this);
            const uid = localStorage.getItem("_live_uid");
            const user = remoteUsers[uid];

            if (!user || !user.audioTrack) {
                console.error("User or audio track not found");
                return;
            }

            const isMuted = mutedUsers[uid] || false;

            if (isMuted) {
                unmuteRemoteUser(uid);
                mutedUsers[uid] = false;
                $icon.html('<i class="bi bi-volume-up-fill"></i>');
            } else {
                muteRemoteUser(uid);
                mutedUsers[uid] = true;
                $icon.html('<i class="bi bi-volume-mute-fill"></i>');
            }
        });

        function muteRemoteUser(uid) {
            const user = remoteUsers[uid];
            if (user && user.audioTrack) {
                user.audioTrack.setVolume(0); // Mute audio playback
            } else {
                console.error("Audio track not found for user:", uid);
            }
        }

        function unmuteRemoteUser(uid) {
            const user = remoteUsers[uid];
            if (user && user.audioTrack) {
                user.audioTrack.setVolume(100); // Unmute audio playback
            } else {
                console.error("Audio track not found for user:", uid);
            }
        }

        $(document).on('click', '#sendLiveChat', function(e) {
            e.preventDefault();

            sendLiveChat()
        })
        $(document).on('keypress', '.comment-input', function(e) {
            if (e.which == 13) {
                e.preventDefault();
                sendLiveChat();
                console.log("clciked")
            }
        });

        $(document).on('click', '#tipButton', function(e) {
            const liveData = getCurrentStreamData()

            $('input[name="liveID"]').val(liveData.live_id)
            $('input.userIdInput').val(liveData.id)
            console.log("live set")
        })

        /*
         * gets the current stream data using uid from query params
         */
        function getCurrentStreamData() {
            // get live stream uid from params
            const url = new URL(window.location.href);
            const videoId = localStorage.getItem("_live_uid")

            // get document element with videoId
            const remoteVideo = document.getElementById(videoId)
            const dataInfo = remoteVideo.getAttribute("data-info");
            const liveData = JSON.parse(dataInfo);

            return liveData
        }

        // 🔁 Called when switching videos or removing one
        function updateButtonStates() {
            // Render the current video
            const live = filteredStreams[currentVideoIndex];
            if (!live) {return;}

            // Remove all current video containers
            const remoteStreams = document.getElementById("remote-streams");
            while (remoteStreams.firstChild) {
                remoteStreams.removeChild(remoteStreams.firstChild);
            }

            // Call your logic to join and render the video for this live
            renderLiveStream(live);
        }

        function playNextVideo() {
            if (
                !filteredStreams ||
                filteredStreams.length <= 1 ||
                currentVideoIndex < 0 ||
                currentVideoIndex >= filteredStreams.length
            ) {
                return;
            }

            currentVideoIndex = (currentVideoIndex + 1) % filteredStreams.length;
            updateButtonStates();
        }

        function playPreviousVideo() {
            if (
                !filteredStreams ||
                filteredStreams.length <= 1 ||
                currentVideoIndex <= 0 ||
                currentVideoIndex >= filteredStreams.length
            ) {
                return;
            }

            currentVideoIndex = (currentVideoIndex - 1 + filteredStreams.length) % filteredStreams.length;
            updateButtonStates();
        }

        function sendLiveChat() {
            const liveData = getCurrentStreamData();
            const id = liveData.live_id
            $.ajax({
                url: '{{ url('comment/live') }}',
                type: "post",
                data: {
                    _token: "{{ csrf_token() }}",
                    live_id: id,
                    comment: $('.comment-input').val().trim()
                },
                success: function(response) {
                    if (response.success) {
                        console.log("comment sent successfully");
                        $('.comment-input').val("");

                    } else {
                        console.error(response.errors)
                    }

                },
                error: function(xhr, status, error) {
                    console.error("AJAX error:", error);
                    swal({
                        title: "Error",
                        text: "An error occurred while processing the payment.",
                        type: "error",
                        confirmButtonText: "OK"
                    });
                }
            })
        }
        document.getElementById("nextButton").addEventListener("click", playNextVideo);
        document.getElementById("prevButton").addEventListener("click", playPreviousVideo);

        // 🚀 Start
        loadLiveStream();

        function updateVisibleComments() {
            const commentBox = document.getElementById("commentOverlay");
            if (!commentBox) return;

            // Get all child divs inside the comment overlay
            const comments = commentBox.querySelectorAll("#comment-wrap");

            // Loop through all comments
            comments.forEach((comment, index) => {
                // Show the last 5 comments, hide the rest
                if (index < comments.length - 5) {
                    comment.style.display = "none"; // Hide older comments
                } else {
                    comment.style.display = "flex"; // Show the latest 5 comments
                }
            });
        }
    </script>


<script>

@endsection

