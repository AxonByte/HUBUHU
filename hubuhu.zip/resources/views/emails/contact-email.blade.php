<h2>Subject: {{$subject}}</h2>
<br>
<h2>From: {{ $full_name }} - {{$email}}</h2>
<br>
<h2>Message:</h2>
<br>
<p>{{$_message}}</p>
