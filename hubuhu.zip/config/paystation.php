<?php

return [
    'merchant_id' => env('PAYSTATION_MERCHANT_ID'),
    'merchant_password' => env('PAYSTATION_MERCHANT_PASSWORD'),
];