<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Xenon\Paystation\Paystation;
use App\Models\PaymentTransaction;
use Log;
use App\Models\User;
use App\Models\PaymentGateways;

class PayStationController extends Controller
{
    //
    public function sendPaystation(Request $request)
    {
        $config = [
            'merchantId' => config('paystation.merchant_id'),
            'password' => config('paystation.merchant_password'),
            'sandbox' => PaymentGateways::where('name', 'Paystation')->first()->sandbox,
        ];

        $invoice_number = 'PSH' . uniqid() . time();

        $paystation = new Paystation($config);
        $user = User::find($request->user_id);
        $paystation->setPaymentParams([
            'invoice_number' => $invoice_number,
            'currency' => 'BDT',
            'payment_amount' => (int) $request->amount, // Make sure it's integer
            'reference' => 'REF' . rand(1000, 9999),
            'client_ip' => request()->ip(),

            // Customer Info
            'cust_name' => $user->name ?? 'Guest User',
            'cust_phone' => $user->phone ?? '01700000000', // fallback phone
            'cust_email' => $user->email ?? 'guest@example.com',
            'cust_address' => $user->address ?? 'Dhaka, Bangladesh',

            // Must match what Paystation expects
            'callback_url' => route('payment.callback'),
            'checkout_items' => 'DIGITAL_GOODS', // or 'PHYSICAL_GOODS'
        ]);

        try {
            // Store the transaction in the database
            PaymentTransaction::create([
                'invoice_number' => $invoice_number,
                'amount' => $request->amount,
                'status' => 'Pending',
                'user_id' => $user->id,
            ]);

            // Get the payment URL by capturing the redirect response
            $paystation->payNow();

        } catch (\Xenon\Paystation\Exception\PaystationException $e) {
            return response()->json([
                'message' => 'Paystation Error: ' . $e->getMessage()
            ], 400);
        }
    }
    public function handleCallback(Request $request)
    {
        $invoice_number = $request->query('invoice_number');
        $trx_id = $request->query('trx_id');

        if (!$invoice_number || !$trx_id) {
            return redirect()->route('home')->with('error', 'Invalid transaction callback.');
        }

        // Set PayStation credentials
        $config = [
            'merchantId' => config('paystation.merchant_id'),
            'password' => config('paystation.merchant_password'),
        ];

        // Create a PayStation instance
        $paystation = new Paystation($config);

        // Verify the transaction
        $response = $paystation->verifyPayment($invoice_number, $trx_id);
        $responseData = json_decode($response, true);
        Log::info('Paystation Test Payment', $responseData);

        if ($responseData['status_code'] == '200' && $responseData['data']['trx_status'] == 'Success') {
            // Update the transaction status in the database
            $transaction = PaymentTransaction::where('invoice_number', $invoice_number)->first();
            if ($transaction && $transaction->status != 'Sucess') {
                User::find($transaction->user_id)->increment('wallet', $responseData['data']['payment_amount']);
                $transaction->update([
                    'status' => 'Success',
                    'trx_id' => $trx_id,
                    'payer_mobile' => $responseData['data']['payer_mobile_no'],
                    'payment_method' => $responseData['data']['payment_method'],
                    'paid_at' => $responseData['data']['order_date_time'],
                ]);
            }

            return redirect()->route('my.wallet')->with('message', 'Payment successful!');
        } else {
            return redirect()->route('my.wallet')->with('error', 'Payment verification failed.');
        }
    }

    public function verifyPayemnt()
    {
        return view('page.verifypay');
    }
}