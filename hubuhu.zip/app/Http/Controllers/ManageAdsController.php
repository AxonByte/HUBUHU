<?php

namespace App\Http\Controllers;

use App\Helper;
use App\Models\{User,Business,AdView,Messages,AdminSettings,Categories,LiveComments,Notifications,LiveStreamings,LiveOnlineUsers,LiveStreamingPrivateRequest,Advertising};
use Illuminate\Http\Request;
use App\Enums\LiveStreamingPrivateStatus;

class ManageAdsController extends Controller
{

    #@====== Landling page =====@#
    public function index()
    {
        $ads=Advertising::get();
        $categories = Categories::get();
        return view('index.manage-ads-landing',compact('categories'));
    }


    #@===== show manage ads listing ========@#
    public function adsListing(){        
        $ads=Advertising::where('user_id', auth()->user()->id)
        ->orWhere(function ($query) {
            $query->where('city', auth()->user()->city)
                  ->where('user_id', '!=', auth()->user()->id);
        })
        ->get(); 
        return view('index.manage-ads',compact('ads'));
    }


    #@======= Store Business Request ====@#
    public function storeBusiness(Request $request)
    {
        $request->validate([
            'business_name' => 'required|string|max:255',
            'category_id' => 'required|integer|max:255',
            'business_logo' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048'
        ]);
        $imagePath = null;
        if ($request->hasFile('business_logo')) {
            $imagePath = $request->file('business_logo')->store('business_logos', 'public');
        }
        Business::create([
            'business_name' => $request->business_name,
            'category_id' => $request->category_id,
            'logo' => $imagePath,
            'user_id' => auth()->user()->id,
        ]);

        return response()->json(['message' => 'Business created successfully']);
    } 
    
    #@======== Track View ======@#
    public function trackView(Request $request)
    {
        $adId = $request->ad_id;
        $watchedSeconds = $request->watched_seconds;

        $user = auth()->user();
        $ad = Advertising::findOrFail($adId);
        $settings = AdminSettings::first();

        // Skip if the viewer is the creator
        if ($user->id === $ad->user_id) {
            return response()->json(['message' => 'Self-views not counted'], 200);
        }
        //
        $videoDuration = $ad->duration ?? 0; // assuming you store duration in DB

        if ($videoDuration > 0 && $watchedSeconds >= $videoDuration && $videoDuration <= 5) {
            $earnedSeconds = $videoDuration;
        } else {
            $earnedSeconds = min($watchedSeconds, 15);
        }

        $perSecondRate = $settings->ppv_rate / 60;

        $totalEarn = round($earnedSeconds * $perSecondRate, 2);
        $adminCommission = round(($totalEarn * $settings->admin_commission) / 100, 2);
        $creatorAmount = $totalEarn - $adminCommission;

        // Update creator balance
        $adCreator = User::find($ad->user_id);
        $adCreator->balance += $creatorAmount;
        $adCreator->save();

        // Add commission to admin
        $adminUser = User::where('role', 'admin')->first();
        if ($adminUser) {
            $adminUser->balance += $adminCommission;
            $adminUser->save();
        }

        // Optionally: log this view
        AdView::create([
            'user_id' => $user->id,
            'ad_id' => $ad->id,
            'watched_seconds' => $watchedSeconds,
            'earned' => $totalEarn,
        ]);

        return response()->json(['earned' => $totalEarn, 'creator_received' => $creatorAmount, 'admin_commission' => $adminCommission], 200);
    }

    
    
    public function fetchBusinesses()
    {
        $businesses = Business::with('category')->latest()->get();
        return response()->json([
            'businesses' => $businesses->map(function ($b) {
                return [
                    'id' => $b->id,
                    'name' => $b->business_name,
                    'category_name' => $b->category->name ?? '',
                    'logo_url' => $b->logo ? asset('public/storage/' . $b->logo) : asset('public/images/icons/shop.png')
                ];
            })
        ]);
    }


    public function pause($id)
    {
        $ad = Advertising::findOrFail($id);
        if ($ad->status === '0') {
            return response()->json(['message' => 'Ad already paused.'], 400);
        }

        $ad->status = '0';
        $ad->ad_status = 'inactive';
        $ad->save();

        return response()->json(['message' => 'Ad paused successfully.']);
    }

    public function reactive($id)
    {
        $ad = Advertising::findOrFail($id);
        
        $ad->status = "1";
        $ad->ad_status = 'active';
        $ad->save();

        return response()->json(['message' => 'Ad Reactive successfully.']);
    }


    public function destroy($id)
    {
        $ad = Advertising::findOrFail($id);
        $ad->delete();
        return response()->json(['message' => 'Ad deleted successfully.']);
    }

    public function deleteBusiness($id)
    {
        $business = Business::findOrFail($id);
        $business->delete();
        return response()->json(['message' => 'Business deleted successfully.']);
    }


    public function updateAdStatus() {
        $ads = Advertising::where('ad_status', 'pause')
            ->where('created_at', '<=', Carbon::now()->subMinutes(5))
            ->get();
    
        foreach ($ads as $ad) {
            $ad->ad_status = 'active';
            $ad->save();
        }
    
        return $ads; // if you want to debug
    }
    


    public function storeAdvertiseRequest(Request $request){        
        // Step 1: Validation (basic version, customize as needed)
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'select_goal' => 'required|string',
            'goal_description' => 'nullable|string',
            'price' => 'required|numeric|min:1',
            'ad_media' => 'nullable|file|mimes:jpeg,png,jpg,gif,mp4,webm|max:10240', // 10MB max
        ]);

        dd($request->all());
        
        // Step 2: Handle File Upload (if present)
        if ($request->hasFile('ad_media')) {
            $file = $request->file('ad_media');
            $fileName = time().'_'.$file->getClientOriginalName();
            $filePath = $file->storeAs('uploads/ads', $fileName, 'public');
        } else {
            $filePath = null;
        }

        // Step 3: Save Advertisement
        $ad = new Advertising();
        $ad->user_id =  auth()->user()->id;
        $ad->title = $request->name;
        $ad->business_id = $request->business_id;
        $ad->address = $request->selected_address;
        $ad->city=$request->city;
        $ad->country=$request->country;
        $ad->address_range = $request->address_range;
        $ad->goal = $request->select_goal;
        $ad->goal_description = $request->goal_description;
        $ad->price = $request->price;
        $ad->ad_file = $filePath;
        $ad->status = "1";
        $ad->ad_status = 'pause';

        // Optional fields based on selected goal
        $ad->whatsapp_number = $request->whatsapp_number;
        $ad->send_message = $request->send_message;
        $ad->visit_now = $request->visit_now;
        $ad->buy_now = $request->buy_now;
        $ad->order_now = $request->order_now;
        $ad->start_now = $request->start_now;
        $ad->install_now = $request->install_now;
        $ad->learn_more = $request->learn_more;

        $ad->save();

        // Step 4: Return a success response
        return response()->json(['success' => true, 'message' => 'Advertisement created successfully']);
    }



}