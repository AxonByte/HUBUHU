<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdView extends Model
{
	protected $guarded = [];
    protected $table = "ad_views";

    protected $fillable = [
        'user_id',
        'ad_id',
        'watched_seconds',
        'earned',
    ];

	public $timestamps = false;

       
}
