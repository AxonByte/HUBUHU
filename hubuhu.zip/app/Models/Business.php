<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Business extends Model
{
	protected $guarded = [];
    protected $table = "business";

    protected $fillable = [
        'user_id',
        'business_name',
        'category_id',
        'logo',
    ];

	public $timestamps = false;

    public function category()
    {
        return $this->belongsTo(Categories::class, 'category_id', 'id');
    }


    
}
